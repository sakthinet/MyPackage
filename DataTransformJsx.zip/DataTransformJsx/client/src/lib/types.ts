export interface DashboardMetrics {
  totalTransformations: number;
  activeConfigurations: number;
  successRate: string;
  databaseTargets: number;
}

export interface FileUploadResponse {
  id: number;
  originalName: string;
  fileName: string;
  filePath: string;
  size: number;
  mimeType: string;
  uploadedAt: Date;
}

export interface TransformationResponse {
  transformation: {
    id: number;
    name: string;
    csvFileName: string;
    xmlContent: string;
    status: string;
    createdAt: Date;
    config: any;
  };
  xmlContent: string;
}
