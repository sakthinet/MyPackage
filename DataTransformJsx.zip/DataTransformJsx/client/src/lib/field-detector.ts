export interface FieldInfo {
  name: string;
  type: FieldType;
  samples: string[];
  confidence: number;
  format?: string;
  nullable: boolean;
  uniqueValues: number;
  totalValues: number;
}

export type FieldType = 
  | 'string'
  | 'integer'
  | 'decimal' 
  | 'date'
  | 'datetime'
  | 'email'
  | 'phone'
  | 'boolean'
  | 'currency'
  | 'percentage'
  | 'url'
  | 'postal_code'
  | 'credit_card'
  | 'ssn'
  | 'uuid';

export class FieldDetector {
  private static readonly patterns = {
    email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
    phone: /^[\+]?[\d\s\-\(\)\.]{7,15}$/,
    url: /^https?:\/\/[^\s/$.?#].[^\s]*$/i,
    uuid: /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i,
    creditCard: /^\d{4}[\s\-]?\d{4}[\s\-]?\d{4}[\s\-]?\d{4}$/,
    ssn: /^\d{3}-?\d{2}-?\d{4}$/,
    postalCode: /^[A-Z0-9][A-Z0-9\-\s]{2,10}$/i,
    currency: /^[\$£€¥]\s*\d+[\d,]*\.?\d*$/,
    percentage: /^\d+\.?\d*%$/,
    date: [
      /^\d{4}-\d{2}-\d{2}$/,
      /^\d{2}\/\d{2}\/\d{4}$/,
      /^\d{1,2}\/\d{1,2}\/\d{4}$/,
      /^\d{2}-\d{2}-\d{4}$/,
      /^\d{1,2}-\d{1,2}-\d{4}$/
    ],
    datetime: [
      /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$/,
      /^\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}$/,
      /^\d{2}\/\d{2}\/\d{4}\s\d{1,2}:\d{2}:\d{2}$/
    ],
    integer: /^-?\d+$/,
    decimal: /^-?\d+\.\d+$/,
    boolean: /^(true|false|yes|no|1|0|y|n)$/i
  };

  static detectFieldTypes(csvData: string[][]): FieldInfo[] {
    if (csvData.length === 0) return [];
    
    const headers = csvData[0];
    const dataRows = csvData.slice(1);
    
    return headers.map((header, columnIndex) => {
      const values = dataRows.map(row => row[columnIndex] || '').filter(val => val.trim() !== '');
      return this.analyzeColumn(header, values);
    });
  }

  private static analyzeColumn(name: string, values: string[]): FieldInfo {
    if (values.length === 0) {
      return {
        name,
        type: 'string',
        samples: [],
        confidence: 1.0,
        nullable: true,
        uniqueValues: 0,
        totalValues: 0
      };
    }

    const uniqueValues = new Set(values).size;
    const totalValues = values.length;
    const samples = values.slice(0, 5);
    
    // Check for specific patterns
    const typeChecks = [
      { type: 'email' as FieldType, check: this.checkEmail },
      { type: 'phone' as FieldType, check: this.checkPhone },
      { type: 'url' as FieldType, check: this.checkUrl },
      { type: 'uuid' as FieldType, check: this.checkUuid },
      { type: 'credit_card' as FieldType, check: this.checkCreditCard },
      { type: 'ssn' as FieldType, check: this.checkSSN },
      { type: 'postal_code' as FieldType, check: this.checkPostalCode },
      { type: 'currency' as FieldType, check: this.checkCurrency },
      { type: 'percentage' as FieldType, check: this.checkPercentage },
      { type: 'datetime' as FieldType, check: this.checkDateTime },
      { type: 'date' as FieldType, check: this.checkDate },
      { type: 'boolean' as FieldType, check: this.checkBoolean },
      { type: 'decimal' as FieldType, check: this.checkDecimal },
      { type: 'integer' as FieldType, check: this.checkInteger }
    ];

    for (const { type, check } of typeChecks) {
      const result = check.call(this, values);
      if (result.confidence > 0.7) {
        return {
          name,
          type,
          samples,
          confidence: result.confidence,
          format: result.format,
          nullable: totalValues < values.length,
          uniqueValues,
          totalValues
        };
      }
    }

    // Default to string
    return {
      name,
      type: 'string',
      samples,
      confidence: 1.0,
      nullable: totalValues < values.length,
      uniqueValues,
      totalValues
    };
  }

  private static checkEmail(values: string[]): { confidence: number; format?: string } {
    const matches = values.filter(val => this.patterns.email.test(val.trim()));
    return { confidence: matches.length / values.length };
  }

  private static checkPhone(values: string[]): { confidence: number; format?: string } {
    const matches = values.filter(val => this.patterns.phone.test(val.trim()));
    return { confidence: matches.length / values.length };
  }

  private static checkUrl(values: string[]): { confidence: number; format?: string } {
    const matches = values.filter(val => this.patterns.url.test(val.trim()));
    return { confidence: matches.length / values.length };
  }

  private static checkUuid(values: string[]): { confidence: number; format?: string } {
    const matches = values.filter(val => this.patterns.uuid.test(val.trim()));
    return { confidence: matches.length / values.length };
  }

  private static checkCreditCard(values: string[]): { confidence: number; format?: string } {
    const matches = values.filter(val => this.patterns.creditCard.test(val.trim()));
    return { confidence: matches.length / values.length };
  }

  private static checkSSN(values: string[]): { confidence: number; format?: string } {
    const matches = values.filter(val => this.patterns.ssn.test(val.trim()));
    return { confidence: matches.length / values.length };
  }

  private static checkPostalCode(values: string[]): { confidence: number; format?: string } {
    const matches = values.filter(val => this.patterns.postalCode.test(val.trim()));
    return { confidence: matches.length / values.length };
  }

  private static checkCurrency(values: string[]): { confidence: number; format?: string } {
    const matches = values.filter(val => this.patterns.currency.test(val.trim()));
    return { confidence: matches.length / values.length };
  }

  private static checkPercentage(values: string[]): { confidence: number; format?: string } {
    const matches = values.filter(val => this.patterns.percentage.test(val.trim()));
    return { confidence: matches.length / values.length };
  }

  private static checkDate(values: string[]): { confidence: number; format?: string } {
    let bestMatch = { count: 0, format: '' };
    
    this.patterns.date.forEach((pattern, index) => {
      const matches = values.filter(val => pattern.test(val.trim()));
      if (matches.length > bestMatch.count) {
        bestMatch = { 
          count: matches.length, 
          format: ['YYYY-MM-DD', 'MM/DD/YYYY', 'M/D/YYYY', 'MM-DD-YYYY', 'M-D-YYYY'][index] 
        };
      }
    });
    
    return { 
      confidence: bestMatch.count / values.length,
      format: bestMatch.format 
    };
  }

  private static checkDateTime(values: string[]): { confidence: number; format?: string } {
    let bestMatch = { count: 0, format: '' };
    
    this.patterns.datetime.forEach((pattern, index) => {
      const matches = values.filter(val => pattern.test(val.trim()));
      if (matches.length > bestMatch.count) {
        bestMatch = { 
          count: matches.length, 
          format: ['YYYY-MM-DDTHH:mm:ss', 'YYYY-MM-DD HH:mm:ss', 'MM/DD/YYYY HH:mm:ss'][index] 
        };
      }
    });
    
    return { 
      confidence: bestMatch.count / values.length,
      format: bestMatch.format 
    };
  }

  private static checkBoolean(values: string[]): { confidence: number; format?: string } {
    const matches = values.filter(val => this.patterns.boolean.test(val.trim()));
    return { confidence: matches.length / values.length };
  }

  private static checkInteger(values: string[]): { confidence: number; format?: string } {
    const matches = values.filter(val => this.patterns.integer.test(val.trim()));
    return { confidence: matches.length / values.length };
  }

  private static checkDecimal(values: string[]): { confidence: number; format?: string } {
    const matches = values.filter(val => this.patterns.decimal.test(val.trim()));
    return { confidence: matches.length / values.length };
  }

  static getFieldTypeIcon(type: FieldType): string {
    const icons: Record<FieldType, string> = {
      string: '📝',
      integer: '🔢',
      decimal: '🔢',
      date: '📅',
      datetime: '🕒',
      email: '📧',
      phone: '📞',
      boolean: '✅',
      currency: '💰',
      percentage: '📊',
      url: '🔗',
      postal_code: '📍',
      credit_card: '💳',
      ssn: '🆔',
      uuid: '🔑'
    };
    return icons[type] || '📝';
  }

  static getFieldTypeColor(type: FieldType): string {
    const colors: Record<FieldType, string> = {
      string: 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200',
      integer: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
      decimal: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
      date: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
      datetime: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
      email: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
      phone: 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200',
      boolean: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200',
      currency: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200',
      percentage: 'bg-teal-100 text-teal-800 dark:bg-teal-900 dark:text-teal-200',
      url: 'bg-cyan-100 text-cyan-800 dark:bg-cyan-900 dark:text-cyan-200',
      postal_code: 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200',
      credit_card: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
      ssn: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
      uuid: 'bg-violet-100 text-violet-800 dark:bg-violet-900 dark:text-violet-200'
    };
    return colors[type] || colors.string;
  }
}