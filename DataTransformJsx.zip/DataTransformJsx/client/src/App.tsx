import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/layout";
import Dashboard from "@/pages/dashboard";
import Configurations from "@/pages/configurations";
import About from "@/pages/about";
import Help from "@/pages/help";
import CsvUpload from "@/pages/csv-upload";
import XmlTransform from "@/pages/xml-transform";
import DatabaseConfig from "@/pages/database-config";
import RestApiConfig from "@/pages/rest-api-config";
import FieldMapping from "@/pages/field-mapping";
import Execute from "@/pages/execute";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/configurations" component={Configurations} />
        <Route path="/about" component={About} />
        <Route path="/help" component={Help} />
        <Route path="/csv-upload" component={CsvUpload} />
        <Route path="/xml-transform" component={XmlTransform} />
        <Route path="/database-config" component={DatabaseConfig} />
        <Route path="/rest-api-config" component={RestApiConfig} />
        <Route path="/field-mapping" component={FieldMapping} />
        <Route path="/execute" component={Execute} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
