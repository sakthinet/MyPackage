import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Database, Users, Shield, Zap } from "lucide-react";

export default function About() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">About TCS Data Migration</h1>
        <p className="text-gray-600 mt-1">Enterprise data migration solution for OpenText InfoArchive</p>
      </div>

      {/* Overview */}
      <Card>
        <CardHeader>
          <CardTitle>Platform Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600 mb-4">
            TCS Data Migration for OpenText InfoArchive is a comprehensive enterprise solution designed to streamline 
            the process of transforming CSV data into XML format and loading it into multiple database systems. 
            Our platform provides intelligent configuration management and automated workflows to ensure reliable 
            and efficient data migration processes.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
            <div className="text-center p-4 border rounded-lg">
              <Database className="w-8 h-8 text-blue-600 mx-auto mb-2" />
              <h3 className="font-medium text-gray-900">Multi-Database</h3>
              <p className="text-sm text-gray-500">Support for PostgreSQL, Oracle, MongoDB</p>
            </div>
            
            <div className="text-center p-4 border rounded-lg">
              <Zap className="w-8 h-8 text-yellow-600 mx-auto mb-2" />
              <h3 className="font-medium text-gray-900">High Performance</h3>
              <p className="text-sm text-gray-500">Optimized batch processing</p>
            </div>
            
            <div className="text-center p-4 border rounded-lg">
              <Shield className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <h3 className="font-medium text-gray-900">Enterprise Security</h3>
              <p className="text-sm text-gray-500">Role-based access control</p>
            </div>
            
            <div className="text-center p-4 border rounded-lg">
              <Users className="w-8 h-8 text-purple-600 mx-auto mb-2" />
              <h3 className="font-medium text-gray-900">Team Collaboration</h3>
              <p className="text-sm text-gray-500">Multi-user workflows</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Key Features */}
      <Card>
        <CardHeader>
          <CardTitle>Key Features</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-medium text-gray-900 mb-3">Data Processing</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• CSV, TSV, and Excel file support</li>
                <li>• Automated data validation</li>
                <li>• Custom transformation rules</li>
                <li>• Error handling and recovery</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-medium text-gray-900 mb-3">XML Transformation</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• TICKETS/CUSTOMER/EDITOR/BOW hierarchy</li>
                <li>• Special character encoding</li>
                <li>• Schema validation</li>
                <li>• Custom XML templates</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-medium text-gray-900 mb-3">Database Integration</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Multiple database system support</li>
                <li>• Connection pooling</li>
                <li>• Transaction management</li>
                <li>• Performance optimization</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-medium text-gray-900 mb-3">Monitoring & Analytics</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Real-time processing status</li>
                <li>• Success rate tracking</li>
                <li>• Error logs and reporting</li>
                <li>• Performance metrics</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Technical Information */}
      <Card>
        <CardHeader>
          <CardTitle>Technical Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-medium text-gray-900 mb-3">System Requirements</h3>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Node.js Version</span>
                  <Badge variant="outline">18.x+</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Memory</span>
                  <Badge variant="outline">4GB RAM</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Storage</span>
                  <Badge variant="outline">10GB+</Badge>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="font-medium text-gray-900 mb-3">Supported Databases</h3>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">PostgreSQL</span>
                  <Badge variant="default">12.x+</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Oracle</span>
                  <Badge variant="default">19c+</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">MongoDB</span>
                  <Badge variant="default">5.0+</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Microsoft SQL</span>
                  <Badge variant="default">2019+</Badge>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Version Information */}
      <Card>
        <CardHeader>
          <CardTitle>Version Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <h3 className="font-medium text-gray-900">Version</h3>
              <p className="text-lg font-bold text-blue-600">1.0.0</p>
            </div>
            
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <h3 className="font-medium text-gray-900">Release Date</h3>
              <p className="text-lg font-bold text-green-600">December 2024</p>
            </div>
            
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <h3 className="font-medium text-gray-900">License</h3>
              <p className="text-lg font-bold text-purple-600">Enterprise</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
