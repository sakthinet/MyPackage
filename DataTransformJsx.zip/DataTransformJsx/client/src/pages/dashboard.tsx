import { useQuery } from "@tanstack/react-query";
import { 
  ArrowUpRight, 
  RefreshCw, 
  CheckCircle, 
  Server,
  Upload,
  Code,
  Database,
  ArrowRight,
  TrendingUp,
  Activity
} from "lucide-react";
import { MetricCard } from "@/components/metric-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import type { DashboardMetrics } from "@/lib/types";

export default function Dashboard() {
  const { data: metrics, isLoading } = useQuery<DashboardMetrics>({
    queryKey: ["/api/dashboard/metrics"],
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="p-6">
              <div className="animate-pulse">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
                <div className="h-8 bg-gray-200 rounded w-1/2 mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-2/3"></div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Total Transformations"
          value={metrics?.totalTransformations || 0}
          icon={RefreshCw}
          iconBgColor="bg-blue-50"
          iconColor="text-blue-600"
          change="+12% from last month"
          changeType="positive"
        />
        
        <MetricCard
          title="Active Configurations"
          value={metrics?.activeConfigurations || 0}
          icon={Server}
          iconBgColor="bg-orange-50"
          iconColor="text-orange-500"
          change="+8 total created"
          changeType="neutral"
        />
        
        <MetricCard
          title="Success Rate"
          value={metrics?.successRate || "0%"}
          icon={CheckCircle}
          iconBgColor="bg-green-50"
          iconColor="text-green-500"
          change="+8.7% improvement"
          changeType="positive"
        />
        
        <MetricCard
          title="Database Targets"
          value={metrics?.databaseTargets || 0}
          icon={Database}
          iconBgColor="bg-purple-50"
          iconColor="text-purple-500"
          subtitle="PostgreSQL, Oracle, MongoDB"
        />
      </div>

      {/* Enhanced Features Section */}
      <Card>
        <CardHeader>
          <CardTitle>Advanced Features</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="p-4 bg-primary/5 dark:bg-primary/10 rounded-lg border border-primary/20 dark:border-primary/30">
              <h3 className="font-medium text-foreground dark:text-foreground mb-2">Advanced Data Transformation</h3>
              <p className="text-sm text-muted-foreground dark:text-muted-foreground">Add advanced data transformation rules with conditional logic</p>
            </div>
            <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800">
              <h3 className="font-medium text-foreground dark:text-foreground mb-2">Automated Scheduling</h3>
              <p className="text-sm text-muted-foreground dark:text-muted-foreground">Create automated scheduling system for batch processing</p>
            </div>
            <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
              <h3 className="font-medium text-foreground dark:text-foreground mb-2">Audit Trail System</h3>
              <p className="text-sm text-muted-foreground dark:text-muted-foreground">Build comprehensive audit trail system with data lineage visualization</p>
            </div>
            <div className="p-4 bg-orange-50 dark:bg-orange-900/20 rounded-lg border border-orange-200 dark:border-orange-800">
              <h3 className="font-medium text-foreground dark:text-foreground mb-2">Animated Loading Indicators</h3>
              <p className="text-sm text-muted-foreground dark:text-muted-foreground">Animated loading indicators for file upload process</p>
            </div>
            <div className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg border border-purple-200 dark:border-purple-800">
              <h3 className="font-medium text-foreground dark:text-foreground mb-2">Interactive Data Preview</h3>
              <p className="text-sm text-muted-foreground dark:text-muted-foreground">One-click data preview with interactive filtering</p>
            </div>
            <div className="p-4 bg-pink-50 dark:bg-pink-900/20 rounded-lg border border-pink-200 dark:border-pink-800">
              <h3 className="font-medium text-foreground dark:text-foreground mb-2">Smart Suggestions</h3>
              <p className="text-sm text-muted-foreground dark:text-muted-foreground">Smart suggestion chips for common data transformation patterns</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Quick Start Process */}
        <div className="lg:col-span-2">
          <Card className="p-6">
            <CardHeader className="p-0 mb-6">
              <CardTitle className="text-lg font-semibold">Quick Start Process</CardTitle>
            </CardHeader>
            <CardContent className="p-0 space-y-4">
              <Link href="/csv-upload">
                <div className="flex items-center p-4 border border-border dark:border-border rounded-lg hover:border-primary dark:hover:border-primary transition-colors cursor-pointer group">
                  <div className="w-12 h-12 bg-blue-50 dark:bg-blue-900/20 rounded-lg flex items-center justify-center mr-4 flex-shrink-0 group-hover:bg-blue-100 dark:group-hover:bg-blue-900/30">
                    <Upload className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium text-foreground dark:text-foreground">Upload CSV File</h3>
                    <p className="text-sm text-muted-foreground dark:text-muted-foreground">Start with customer data upload and validation</p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-muted-foreground dark:text-muted-foreground group-hover:text-primary dark:group-hover:text-primary" />
                </div>
              </Link>

              <Link href="/xml-transform">
                <div className="flex items-center p-4 border border-border dark:border-border rounded-lg hover:border-primary dark:hover:border-primary transition-colors cursor-pointer group">
                  <div className="w-12 h-12 bg-orange-50 dark:bg-orange-900/20 rounded-lg flex items-center justify-center mr-4 flex-shrink-0 group-hover:bg-orange-100 dark:group-hover:bg-orange-900/30">
                    <Code className="w-5 h-5 text-orange-500 dark:text-orange-400" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium text-foreground dark:text-foreground">XML Transformation</h3>
                    <p className="text-sm text-muted-foreground dark:text-muted-foreground">Convert to TICKETS CUSTOMER/EDITOR/BOW hierarchy and special character encoding</p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-muted-foreground dark:text-muted-foreground group-hover:text-primary dark:group-hover:text-primary" />
                </div>
              </Link>

              <Link href="/database-config">
                <div className="flex items-center p-4 border border-border dark:border-border rounded-lg hover:border-primary dark:hover:border-primary transition-colors cursor-pointer group">
                  <div className="w-12 h-12 bg-green-50 dark:bg-green-900/20 rounded-lg flex items-center justify-center mr-4 flex-shrink-0 group-hover:bg-green-100 dark:group-hover:bg-green-900/30">
                    <Database className="w-5 h-5 text-green-500 dark:text-green-400" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium text-foreground dark:text-foreground">Database Loading</h3>
                    <p className="text-sm text-muted-foreground dark:text-muted-foreground">Execute to target database systems</p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-muted-foreground dark:text-muted-foreground group-hover:text-primary dark:group-hover:text-primary" />
                </div>
              </Link>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity */}
        <Card className="p-6">
          <CardHeader className="p-0 mb-6">
            <CardTitle className="text-lg font-semibold">Recent Activity</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Activity className="w-6 h-6 text-gray-400" />
              </div>
              <p className="text-sm text-gray-500 mb-2">No recent activity</p>
              <p className="text-xs text-gray-400">Start by uploading a CSV file</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Functional Areas Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* CSV Management */}
        <Card className="p-6">
          <CardHeader className="p-0 mb-6">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg font-semibold">CSV Management</CardTitle>
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                Active
              </span>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <p className="text-sm text-gray-600 mb-6">
              Upload, validate, and preview customer data files with intelligent format detection.
            </p>
            
            <Link href="/csv-upload">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-600 transition-colors cursor-pointer mb-4 file-drop-zone">
                <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                <p className="text-sm font-medium text-gray-700">Drop CSV files here or click to browse</p>
                <p className="text-xs text-gray-500 mt-1">Supports CSV, TSV, and Excel formats</p>
              </div>
            </Link>
            
            <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
              <Link href="/csv-upload">
                <Upload className="w-4 h-4 mr-2" />
                Manage Files
              </Link>
            </Button>
          </CardContent>
        </Card>

        {/* XML Transformation */}
        <Card className="p-6">
          <CardHeader className="p-0 mb-6">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg font-semibold">XML Transformation</CardTitle>
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                Ready
              </span>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <p className="text-sm text-gray-600 mb-6">
              Convert CSV to structured XML with TICKETS/CUSTOMER/EDITOR/BOW hierarchy and special character encoding.
            </p>
            
            <div className="bg-gray-50 rounded-lg p-4 mb-4 font-mono text-xs">
              <div className="text-gray-500">&lt;?xml version="1.0" encoding="UTF-8"?&gt;</div>
              <div className="text-blue-600">&lt;TICKETS&gt;</div>
              <div className="ml-4 text-green-600">&lt;CUSTOMER&gt;</div>
              <div className="ml-8 text-gray-700">...</div>
              <div className="ml-4 text-green-600">&lt;/CUSTOMER&gt;</div>
              <div className="text-blue-600">&lt;/TICKETS&gt;</div>
            </div>
            
            <Button asChild className="w-full bg-orange-500 hover:bg-orange-600">
              <Link href="/xml-transform">
                <Code className="w-4 h-4 mr-2" />
                Transform Data
              </Link>
            </Button>
          </CardContent>
        </Card>

        {/* Database Configuration */}
        <Card className="p-6">
          <CardHeader className="p-0 mb-6">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg font-semibold">Database Configuration</CardTitle>
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                Ready
              </span>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <p className="text-sm text-gray-600 mb-6">
              Setup connections to PostgreSQL, MS-SQL, Oracle, MongoDB and other database systems.
            </p>
            
            <div className="space-y-3 mb-4">
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Database className="w-4 h-4 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">PostgreSQL</p>
                    <p className="text-xs text-gray-500">Production DB</p>
                  </div>
                </div>
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center">
                    <Database className="w-4 h-4 text-orange-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">MongoDB</p>
                    <p className="text-xs text-gray-500">Analytics DB</p>
                  </div>
                </div>
                <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
              </div>
            </div>
            
            <Button asChild className="w-full bg-purple-600 hover:bg-purple-700">
              <Link href="/database-config">
                <Server className="w-4 h-4 mr-2" />
                Configure Databases
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
