import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { 
  Plug, 
  Plus, 
  Edit, 
  Trash2, 
  TestTube,
  CheckCircle,
  XCircle,
  Globe,
  Key,
  Settings
} from "lucide-react";

interface RestApiConfig {
  id: number;
  name: string;
  baseUrl: string;
  method: string;
  endpoint: string;
  headers: Record<string, string>;
  authentication: {
    type: 'none' | 'bearer' | 'basic' | 'apikey';
    credentials: Record<string, string>;
  };
  isActive: boolean;
  createdAt: Date;
}

interface InsertRestApiConfig {
  name: string;
  baseUrl: string;
  method: string;
  endpoint: string;
  headers: Record<string, string>;
  authentication: {
    type: 'none' | 'bearer' | 'basic' | 'apikey';
    credentials: Record<string, string>;
  };
  isActive: boolean;
}

export default function RestApiConfig() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [testingConnection, setTestingConnection] = useState<number | null>(null);
  const [authType, setAuthType] = useState<'none' | 'bearer' | 'basic' | 'apikey'>('none');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Mock data for demonstration
  const mockConfigs: RestApiConfig[] = [
    {
      id: 1,
      name: "InfoArchive API",
      baseUrl: "https://api.infoarchive.com",
      method: "POST",
      endpoint: "/v1/data/import",
      headers: { "Content-Type": "application/json" },
      authentication: {
        type: "bearer",
        credentials: { token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..." }
      },
      isActive: true,
      createdAt: new Date()
    },
    {
      id: 2,
      name: "Backup Service",
      baseUrl: "https://backup.company.com",
      method: "PUT",
      endpoint: "/api/archive",
      headers: { "Content-Type": "application/xml" },
      authentication: {
        type: "apikey",
        credentials: { apiKey: "ak_live_..." }
      },
      isActive: false,
      createdAt: new Date()
    }
  ];

  const { data: configs, isLoading } = useQuery<RestApiConfig[]>({
    queryKey: ["/api/rest-configs"],
    queryFn: () => Promise.resolve(mockConfigs),
  });

  const form = useForm<InsertRestApiConfig>({
    defaultValues: {
      name: "",
      baseUrl: "https://",
      method: "POST",
      endpoint: "/api/",
      headers: {},
      authentication: {
        type: "none",
        credentials: {}
      },
      isActive: true,
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertRestApiConfig): Promise<RestApiConfig> => {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      const newConfig: RestApiConfig = {
        ...data,
        id: Date.now(),
        createdAt: new Date()
      };
      return newConfig;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/rest-configs"] });
      setDialogOpen(false);
      form.reset();
      toast({
        title: "REST API configuration created",
        description: "Your API configuration has been successfully added.",
      });
    },
    onError: () => {
      toast({
        title: "Failed to create configuration",
        description: "There was an error creating the REST API configuration.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (data: InsertRestApiConfig) => {
    createMutation.mutate(data);
  };

  const handleTestConnection = async (config: RestApiConfig) => {
    setTestingConnection(config.id);
    
    // Simulate connection test
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setTestingConnection(null);
    
    // Random success/failure for demo
    const success = Math.random() > 0.3;
    
    if (success) {
      toast({
        title: "Connection successful",
        description: `Successfully connected to ${config.name}`,
      });
    } else {
      toast({
        title: "Connection failed",
        description: `Failed to connect to ${config.name}. Please check your configuration.`,
        variant: "destructive",
      });
    }
  };

  const getMethodColor = (method: string) => {
    switch (method.toUpperCase()) {
      case 'GET': return 'bg-green-100 text-green-700';
      case 'POST': return 'bg-blue-100 text-blue-700';
      case 'PUT': return 'bg-orange-100 text-orange-700';
      case 'DELETE': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getAuthIcon = (type: string) => {
    switch (type) {
      case 'bearer': return <Key className="w-4 h-4 text-blue-600" />;
      case 'basic': return <Settings className="w-4 h-4 text-green-600" />;
      case 'apikey': return <Plug className="w-4 h-4 text-purple-600" />;
      default: return <Globe className="w-4 h-4 text-gray-600" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-foreground dark:text-foreground">REST API Configuration</h1>
          <p className="text-muted-foreground dark:text-muted-foreground mt-1">Configure REST API endpoints for data export and integration</p>
        </div>
        
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90">
              <Plus className="w-4 h-4 mr-2" />
              Add API Config
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Add REST API Configuration</DialogTitle>
            </DialogHeader>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Configuration Name</Label>
                <Input
                  id="name"
                  placeholder="e.g., InfoArchive Export API"
                  {...form.register('name')}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="method">HTTP Method</Label>
                  <Select
                    value={form.watch('method')}
                    onValueChange={(value) => form.setValue('method', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select method" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="GET">GET</SelectItem>
                      <SelectItem value="POST">POST</SelectItem>
                      <SelectItem value="PUT">PUT</SelectItem>
                      <SelectItem value="PATCH">PATCH</SelectItem>
                      <SelectItem value="DELETE">DELETE</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="baseUrl">Base URL</Label>
                  <Input
                    id="baseUrl"
                    placeholder="https://api.example.com"
                    {...form.register('baseUrl')}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="endpoint">Endpoint Path</Label>
                <Input
                  id="endpoint"
                  placeholder="/v1/data/import"
                  {...form.register('endpoint')}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="authType">Authentication Type</Label>
                <Select
                  value={authType}
                  onValueChange={(value: any) => {
                    setAuthType(value);
                    form.setValue('authentication.type', value);
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select authentication" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No Authentication</SelectItem>
                    <SelectItem value="bearer">Bearer Token</SelectItem>
                    <SelectItem value="basic">Basic Auth</SelectItem>
                    <SelectItem value="apikey">API Key</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {authType === 'bearer' && (
                <div className="space-y-2">
                  <Label htmlFor="token">Bearer Token</Label>
                  <Textarea
                    id="token"
                    placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                    className="h-20"
                  />
                </div>
              )}

              {authType === 'basic' && (
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="username">Username</Label>
                    <Input id="username" placeholder="username" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">Password</Label>
                    <Input id="password" type="password" placeholder="password" />
                  </div>
                </div>
              )}

              {authType === 'apikey' && (
                <div className="space-y-2">
                  <Label htmlFor="apikey">API Key</Label>
                  <Input id="apikey" placeholder="ak_live_..." />
                </div>
              )}

              <div className="flex items-center space-x-2">
                <Switch
                  id="isActive"
                  checked={form.watch('isActive') || false}
                  onCheckedChange={(checked) => form.setValue('isActive', checked || false)}
                />
                <Label htmlFor="isActive">Set as active configuration</Label>
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={createMutation.isPending}>
                  {createMutation.isPending ? 'Creating...' : 'Create Configuration'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* API Configurations */}
      <Card>
        <CardHeader>
          <CardTitle>API Endpoints</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="animate-pulse flex items-center space-x-4">
                    <div className="w-12 h-12 bg-gray-200 dark:bg-gray-700 rounded-lg"></div>
                    <div>
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-32 mb-2"></div>
                      <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-48"></div>
                    </div>
                  </div>
                  <div className="w-20 h-8 bg-gray-200 dark:bg-gray-700 rounded"></div>
                </div>
              ))}
            </div>
          ) : configs && configs.length > 0 ? (
            <div className="space-y-4">
              {configs.map((config) => (
                <div key={config.id} className="flex items-center justify-between p-4 border border-border dark:border-border rounded-lg hover:bg-muted/50 dark:hover:bg-muted/50">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-primary/10 dark:bg-primary/10 rounded-lg flex items-center justify-center">
                      <Plug className="w-6 h-6 text-primary dark:text-primary" />
                    </div>
                    <div>
                      <h3 className="font-medium text-foreground dark:text-foreground">{config.name}</h3>
                      <div className="flex items-center space-x-2 text-sm text-muted-foreground dark:text-muted-foreground">
                        <Badge className={getMethodColor(config.method)} variant="outline">
                          {config.method}
                        </Badge>
                        <span>{config.baseUrl}{config.endpoint}</span>
                      </div>
                      <div className="flex items-center space-x-2 text-xs text-muted-foreground dark:text-muted-foreground mt-1">
                        {getAuthIcon(config.authentication.type)}
                        <span>{config.authentication.type === 'none' ? 'No Auth' : config.authentication.type.toUpperCase()}</span>
                        <span>•</span>
                        <span>Created {new Date(String(config.createdAt)).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <Badge variant={config.isActive ? "default" : "secondary"}>
                      {config.isActive ? (
                        <>
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Active
                        </>
                      ) : (
                        <>
                          <XCircle className="w-3 h-3 mr-1" />
                          Inactive
                        </>
                      )}
                    </Badge>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleTestConnection(config)}
                      disabled={testingConnection === config.id}
                    >
                      <TestTube className={`w-4 h-4 ${testingConnection === config.id ? 'animate-spin' : ''}`} />
                    </Button>
                    
                    <Button variant="outline" size="sm">
                      <Edit className="w-4 h-4" />
                    </Button>
                    
                    <Button variant="outline" size="sm">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Plug className="w-12 h-12 text-muted-foreground dark:text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground dark:text-muted-foreground mb-2">No API configurations found</p>
              <p className="text-sm text-muted-foreground dark:text-muted-foreground">Add your first REST API configuration to get started</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* API Usage Guidelines */}
      <Card>
        <CardHeader>
          <CardTitle>API Integration Guidelines</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-medium text-foreground dark:text-foreground mb-3">Supported Methods</h3>
              <ul className="space-y-2 text-sm text-muted-foreground dark:text-muted-foreground">
                <li className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                  GET - Retrieve data from APIs
                </li>
                <li className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                  POST - Send transformed data
                </li>
                <li className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                  PUT - Update existing records
                </li>
                <li className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                  PATCH - Partial updates
                </li>
                <li className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                  DELETE - Remove data entries
                </li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-medium text-foreground dark:text-foreground mb-3">Authentication Types</h3>
              <ul className="space-y-2 text-sm text-muted-foreground dark:text-muted-foreground">
                <li>• Bearer Token - JWT or OAuth2 tokens</li>
                <li>• Basic Auth - Username and password</li>
                <li>• API Key - Custom API key authentication</li>
                <li>• No Auth - Public endpoints</li>
                <li>• Custom Headers - Additional authentication headers</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}