import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Code, 
  Play, 
  FileText, 
  CheckCircle, 
  AlertCircle,
  Download,
  Copy,
  Eye
} from "lucide-react";
import type { CsvFile, Transformation } from "@shared/schema";
import type { TransformationResponse } from "@/lib/types";
import { ProcessFlow } from "@/components/process-flow";
import { XmlViewer } from "@/components/xml-viewer";
import { useLocation } from "wouter";

export default function XmlTransform() {
  const [selectedFile, setSelectedFile] = useState<string>("");
  const [xmlOutput, setXmlOutput] = useState<string>("");
  const [showPreview, setShowPreview] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();

  const { data: csvFiles, isLoading: filesLoading } = useQuery<CsvFile[]>({
    queryKey: ["/api/csv/files"],
  });

  const { data: transformations, isLoading: transformationsLoading } = useQuery<Transformation[]>({
    queryKey: ["/api/transformations"],
  });

  const transformMutation = useMutation({
    mutationFn: async (data: { csvFileId: number; transformationConfig?: any }): Promise<TransformationResponse> => {
      const response = await fetch('/api/xml/transform', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        throw new Error(`Transform failed: ${response.statusText}`);
      }
      
      return await response.json();
    },
    onSuccess: (data) => {
      if (data && data.xmlContent) {
        setXmlOutput(data.xmlContent);
        setShowPreview(true);
      }
      queryClient.invalidateQueries({ queryKey: ["/api/transformations"] });
      toast({
        title: "Transformation completed",
        description: "Your CSV data has been successfully transformed to XML.",
      });
    },
    onError: () => {
      toast({
        title: "Transformation failed",
        description: "There was an error transforming your data. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleTransform = () => {
    if (!selectedFile) {
      toast({
        title: "No file selected",
        description: "Please select a CSV file to transform.",
        variant: "destructive",
      });
      return;
    }

    const csvFileId = parseInt(selectedFile);
    transformMutation.mutate({ 
      csvFileId,
      transformationConfig: {
        encoding: "UTF-8",
        hierarchy: "TICKETS/CUSTOMER/EDITOR/BOW",
        specialCharacters: true
      }
    });
  };

  const handleCopyXml = () => {
    if (xmlOutput) {
      navigator.clipboard.writeText(xmlOutput);
      toast({
        title: "XML copied",
        description: "The XML content has been copied to your clipboard.",
      });
    }
  };

  const sampleXmlStructure = `<?xml version="1.0" encoding="UTF-8"?>
<TICKETS>
  <CUSTOMER>
    <EDITOR>
      <BOW>
        <CUSTOMER_ID>123456</CUSTOMER_ID>
        <CUSTOMER_NAME>John Doe</CUSTOMER_NAME>
        <EMAIL>john.doe@example.com</EMAIL>
        <PHONE>+1-555-0123</PHONE>
        <ADDRESS>
          <STREET>123 Main St</STREET>
          <CITY>Anytown</CITY>
          <STATE>NY</STATE>
          <ZIP>12345</ZIP>
        </ADDRESS>
        <REGISTRATION_DATE>2024-01-15</REGISTRATION_DATE>
        <STATUS>ACTIVE</STATUS>
      </BOW>
    </EDITOR>
  </CUSTOMER>
</TICKETS>`;

  const handleNext = () => {
    setLocation("/database-config");
  };

  return (
    <div className="space-y-6">
      <ProcessFlow 
        currentStep={2} 
        onNext={xmlOutput ? handleNext : undefined}
        showNextButton={!!xmlOutput}
      />
      
      <div>
        <h1 className="text-2xl font-bold text-foreground dark:text-foreground">XML Transformation</h1>
        <p className="text-muted-foreground dark:text-muted-foreground mt-1">Transform CSV data into structured XML format</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Transformation Setup */}
        <Card>
          <CardHeader>
            <CardTitle>Transform Configuration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium text-foreground dark:text-foreground mb-2 block">
                Select CSV File
              </label>
              <Select value={selectedFile} onValueChange={setSelectedFile}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a CSV file to transform" />
                </SelectTrigger>
                <SelectContent>
                  {csvFiles?.map((file) => (
                    <SelectItem key={file.id} value={file.id.toString()}>
                      {file.originalName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-3">
              <h3 className="text-sm font-medium text-gray-700">Transformation Settings</h3>
              
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="text-sm font-medium text-gray-900">XML Encoding</p>
                  <p className="text-xs text-gray-500">Character encoding for output</p>
                </div>
                <Badge variant="outline">UTF-8</Badge>
              </div>

              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="text-sm font-medium text-gray-900">XML Hierarchy</p>
                  <p className="text-xs text-gray-500">Document structure format</p>
                </div>
                <Badge variant="outline">TICKETS/CUSTOMER/EDITOR/BOW</Badge>
              </div>

              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="text-sm font-medium text-gray-900">Special Characters</p>
                  <p className="text-xs text-gray-500">Handle special character encoding</p>
                </div>
                <Badge variant="default">Enabled</Badge>
              </div>
            </div>

            <Button 
              onClick={handleTransform}
              disabled={!selectedFile || transformMutation.isPending}
              className="w-full bg-orange-500 hover:bg-orange-600"
            >
              {transformMutation.isPending ? (
                <>
                  <Code className="w-4 h-4 mr-2 animate-spin" />
                  Transforming...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 mr-2" />
                  Start Transformation
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* XML Preview */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>XML Preview</CardTitle>
              {xmlOutput && (
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" onClick={handleCopyXml}>
                    <Copy className="w-4 h-4 mr-1" />
                    Copy
                  </Button>
                  <Button variant="outline" size="sm">
                    <Download className="w-4 h-4 mr-1" />
                    Download
                  </Button>
                </div>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {xmlOutput ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Badge variant="default" className="bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Transformation Complete
                  </Badge>
                  <div className="flex items-center space-x-2">
                    <span className="text-xs text-muted-foreground dark:text-muted-foreground">
                      {xmlOutput.split('<ROW').length - 1} records transformed
                    </span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowPreview(!showPreview)}
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      {showPreview ? 'Hide' : 'Show'} Preview
                    </Button>
                  </div>
                </div>

                {showPreview && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs text-muted-foreground dark:text-muted-foreground">
                      <span>XML Preview ({Math.round(xmlOutput.length / 1024)}KB)</span>
                      <span>TICKETS/CUSTOMER/EDITOR/BOW Structure</span>
                    </div>
                    <div className="relative bg-slate-950 border border-slate-700 rounded-lg">
                      <div className="absolute top-2 right-2 flex space-x-1 z-10">
                        <Badge className="text-xs bg-slate-800 text-slate-300 border-slate-600">
                          XML
                        </Badge>
                        <Badge className="text-xs bg-blue-900 text-blue-200 border-blue-700">
                          UTF-8
                        </Badge>
                        <Badge className="text-xs bg-green-900 text-green-200 border-green-700">
                          CUSTOMER08
                        </Badge>
                      </div>
                      <pre className="p-4 text-xs font-mono text-green-400 overflow-auto max-h-96 whitespace-pre-wrap leading-relaxed">
                        {xmlOutput}
                      </pre>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-12">
                <Code className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500 mb-2">No transformation result yet</p>
                <p className="text-sm text-gray-400">Select a CSV file and run transformation to see XML output</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Sample XML Structure */}
      <Card>
        <CardHeader>
          <CardTitle>Expected XML Structure</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-600 mb-4">
            Your CSV data will be transformed into the following XML structure following the TICKETS/CUSTOMER/EDITOR/BOW hierarchy:
          </p>
          <Textarea
            value={sampleXmlStructure}
            readOnly
            className="font-mono text-xs h-64 resize-none"
          />
        </CardContent>
      </Card>

      {/* Recent Transformations */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Transformations</CardTitle>
        </CardHeader>
        <CardContent>
          {transformationsLoading ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="animate-pulse flex items-center space-x-4">
                    <div className="w-12 h-12 bg-gray-200 rounded-lg"></div>
                    <div>
                      <div className="h-4 bg-gray-200 rounded w-32 mb-2"></div>
                      <div className="h-3 bg-gray-200 rounded w-24"></div>
                    </div>
                  </div>
                  <div className="w-16 h-8 bg-gray-200 rounded"></div>
                </div>
              ))}
            </div>
          ) : transformations && transformations.length > 0 ? (
            <div className="space-y-4">
              {transformations.map((transformation) => (
                <div key={transformation.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-orange-50 rounded-lg flex items-center justify-center">
                      <Code className="w-6 h-6 text-orange-600" />
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900">{transformation.name}</h3>
                      <div className="flex items-center space-x-2 text-sm text-gray-500">
                        <span>Source: {transformation.csvFileName}</span>
                        <span>•</span>
                        <span>Created {transformation.createdAt ? new Date(String(transformation.createdAt)).toLocaleDateString() : 'Unknown'}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Badge variant={transformation.status === 'completed' ? 'default' : 'secondary'}>
                      {transformation.status === 'completed' ? (
                        <>
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Completed
                        </>
                      ) : (
                        <>
                          <AlertCircle className="w-3 h-3 mr-1" />
                          {transformation.status}
                        </>
                      )}
                    </Badge>
                    <Button variant="outline" size="sm">
                      <Eye className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500 mb-2">No transformations yet</p>
              <p className="text-sm text-gray-400">Start your first transformation to see results here</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
