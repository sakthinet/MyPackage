import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { 
  Shuffle, 
  Plus, 
  Trash2, 
  ArrowRight,
  FileText,
  Database,
  Code,
  Settings,
  Eye,
  Download
} from "lucide-react";

interface FieldMapping {
  id: string;
  sourceField: string;
  targetField: string;
  transformation: string;
  conditionalLogic?: string;
  isRequired: boolean;
}

interface MappingProfile {
  id: number;
  name: string;
  description: string;
  csvFields: string[];
  xmlStructure: string;
  mappings: FieldMapping[];
  createdAt: Date;
}

export default function FieldMapping() {
  const [selectedProfile, setSelectedProfile] = useState<string>("");
  const [mappings, setMappings] = useState<FieldMapping[]>([
    {
      id: "1",
      sourceField: "customer_id",
      targetField: "CUSTOMER_ID",
      transformation: "direct",
      isRequired: true
    },
    {
      id: "2",
      sourceField: "full_name",
      targetField: "CUSTOMER_NAME",
      transformation: "uppercase",
      isRequired: true
    },
    {
      id: "3",
      sourceField: "email",
      targetField: "EMAIL",
      transformation: "lowercase",
      conditionalLogic: "if(email.contains('@'))",
      isRequired: false
    }
  ]);

  const [showAdvancedRules, setShowAdvancedRules] = useState(false);
  const [previewMode, setPreviewMode] = useState(false);

  // Mock CSV fields from uploaded file
  const csvFields = [
    "customer_id", "full_name", "first_name", "last_name", "email", 
    "phone", "address", "city", "state", "zip_code", "registration_date", "status"
  ];

  // XML target fields
  const xmlFields = [
    "CUSTOMER_ID", "CUSTOMER_NAME", "EMAIL", "PHONE", "ADDRESS/STREET", 
    "ADDRESS/CITY", "ADDRESS/STATE", "ADDRESS/ZIP", "REGISTRATION_DATE", "STATUS"
  ];

  const transformationTypes = [
    { value: "direct", label: "Direct Copy" },
    { value: "uppercase", label: "Convert to Uppercase" },
    { value: "lowercase", label: "Convert to Lowercase" },
    { value: "trim", label: "Remove Whitespace" },
    { value: "date_format", label: "Format Date" },
    { value: "concat", label: "Concatenate Fields" },
    { value: "split", label: "Split Field" },
    { value: "regex", label: "Regular Expression" },
    { value: "conditional", label: "Conditional Logic" }
  ];

  const addMapping = () => {
    const newMapping: FieldMapping = {
      id: Date.now().toString(),
      sourceField: "",
      targetField: "",
      transformation: "direct",
      isRequired: false
    };
    setMappings([...mappings, newMapping]);
  };

  const updateMapping = (id: string, field: keyof FieldMapping, value: any) => {
    setMappings(mappings.map(mapping => 
      mapping.id === id ? { ...mapping, [field]: value } : mapping
    ));
  };

  const removeMapping = (id: string) => {
    setMappings(mappings.filter(mapping => mapping.id !== id));
  };

  const generatePreview = () => {
    const sampleData = {
      customer_id: "CUST_001",
      full_name: "john doe",
      email: "JOHN.DOE@EXAMPLE.COM",
      phone: "555-0123"
    };

    return mappings.map(mapping => {
      let transformedValue = sampleData[mapping.sourceField as keyof typeof sampleData] || "";
      
      switch (mapping.transformation) {
        case "uppercase":
          transformedValue = transformedValue.toUpperCase();
          break;
        case "lowercase":
          transformedValue = transformedValue.toLowerCase();
          break;
        case "trim":
          transformedValue = transformedValue.trim();
          break;
      }

      return {
        ...mapping,
        sampleInput: sampleData[mapping.sourceField as keyof typeof sampleData] || "",
        sampleOutput: transformedValue
      };
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-foreground dark:text-foreground">Field Mapping</h1>
          <p className="text-muted-foreground dark:text-muted-foreground mt-1">Configure data transformation rules with conditional logic</p>
        </div>
        
        <div className="flex space-x-2">
          <Button variant="outline" onClick={() => setPreviewMode(!previewMode)}>
            <Eye className="w-4 h-4 mr-2" />
            {previewMode ? 'Hide Preview' : 'Show Preview'}
          </Button>
          <Button className="bg-primary hover:bg-primary/90">
            <Download className="w-4 h-4 mr-2" />
            Save Mapping
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Source Fields */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <FileText className="w-5 h-5 mr-2" />
              Source CSV Fields
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {csvFields.map((field, index) => (
                <div 
                  key={index}
                  className="p-3 border border-border dark:border-border rounded-lg hover:bg-muted/50 dark:hover:bg-muted/50 cursor-pointer transition-colors"
                  draggable
                >
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-foreground dark:text-foreground">{field}</span>
                    <Badge variant="outline" className="text-xs">
                      {field.includes('_') ? 'String' : 'Auto'}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground dark:text-muted-foreground mt-1">
                    Sample: {field === 'customer_id' ? 'CUST_001' : 
                             field === 'full_name' ? 'John Doe' :
                             field === 'email' ? 'john@example.com' : 'Sample data'}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Mapping Configuration */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center">
                <Shuffle className="w-5 h-5 mr-2" />
                Field Mappings
              </div>
              <Button size="sm" onClick={addMapping}>
                <Plus className="w-4 h-4 mr-1" />
                Add
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {mappings.map((mapping) => (
                <div key={mapping.id} className="p-4 border border-border dark:border-border rounded-lg space-y-3">
                  <div className="flex items-center justify-between">
                    <Badge variant={mapping.isRequired ? "default" : "secondary"}>
                      {mapping.isRequired ? "Required" : "Optional"}
                    </Badge>
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      onClick={() => removeMapping(mapping.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-xs">Source Field</Label>
                    <Select
                      value={mapping.sourceField}
                      onValueChange={(value) => updateMapping(mapping.id, 'sourceField', value)}
                    >
                      <SelectTrigger className="h-8">
                        <SelectValue placeholder="Select source field" />
                      </SelectTrigger>
                      <SelectContent>
                        {csvFields.map((field) => (
                          <SelectItem key={field} value={field}>
                            {field}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center justify-center py-2">
                    <ArrowRight className="w-4 h-4 text-muted-foreground dark:text-muted-foreground" />
                  </div>

                  <div className="space-y-2">
                    <Label className="text-xs">Target XML Field</Label>
                    <Select
                      value={mapping.targetField}
                      onValueChange={(value) => updateMapping(mapping.id, 'targetField', value)}
                    >
                      <SelectTrigger className="h-8">
                        <SelectValue placeholder="Select target field" />
                      </SelectTrigger>
                      <SelectContent>
                        {xmlFields.map((field) => (
                          <SelectItem key={field} value={field}>
                            {field}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-xs">Transformation</Label>
                    <Select
                      value={mapping.transformation}
                      onValueChange={(value) => updateMapping(mapping.id, 'transformation', value)}
                    >
                      <SelectTrigger className="h-8">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {transformationTypes.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {mapping.transformation === 'conditional' && (
                    <div className="space-y-2">
                      <Label className="text-xs">Conditional Logic</Label>
                      <Textarea
                        value={mapping.conditionalLogic || ''}
                        onChange={(e) => updateMapping(mapping.id, 'conditionalLogic', e.target.value)}
                        placeholder="if(field.length > 0) return field.toUpperCase()"
                        className="h-16 text-xs"
                      />
                    </div>
                  )}

                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={mapping.isRequired}
                      onCheckedChange={(checked) => updateMapping(mapping.id, 'isRequired', checked)}
                    />
                    <Label className="text-xs">Required field</Label>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Target XML Structure */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Code className="w-5 h-5 mr-2" />
              Target XML Fields
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {xmlFields.map((field, index) => (
                <div 
                  key={index}
                  className="p-3 border border-border dark:border-border rounded-lg hover:bg-muted/50 dark:hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-foreground dark:text-foreground">{field}</span>
                    <Badge 
                      variant={mappings.some(m => m.targetField === field) ? "default" : "outline"}
                      className="text-xs"
                    >
                      {mappings.some(m => m.targetField === field) ? 'Mapped' : 'Available'}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground dark:text-muted-foreground mt-1">
                    XML Path: &lt;{field.replace('/', '&gt;&lt;')}&gt;
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Advanced Features */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center">
              <Settings className="w-5 h-5 mr-2" />
              Advanced Data Transformation Rules
            </div>
            <Button 
              variant="ghost" 
              onClick={() => setShowAdvancedRules(!showAdvancedRules)}
            >
              {showAdvancedRules ? 'Hide' : 'Show'} Advanced
            </Button>
          </CardTitle>
        </CardHeader>
        {showAdvancedRules && (
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h3 className="font-medium text-foreground dark:text-foreground">Conditional Logic Templates</h3>
                <div className="space-y-2">
                  <div className="p-3 bg-muted/50 dark:bg-muted/50 rounded-lg">
                    <Label className="text-xs font-medium">Email Validation</Label>
                    <code className="block text-xs mt-1 text-muted-foreground dark:text-muted-foreground">
                      if(email.contains('@') && email.contains('.')) return email.toLowerCase()
                    </code>
                  </div>
                  <div className="p-3 bg-muted/50 dark:bg-muted/50 rounded-lg">
                    <Label className="text-xs font-medium">Date Formatting</Label>
                    <code className="block text-xs mt-1 text-muted-foreground dark:text-muted-foreground">
                      if(date.matches('\\d{2}/\\d{2}/\\d{4}')) return formatDate(date, 'YYYY-MM-DD')
                    </code>
                  </div>
                  <div className="p-3 bg-muted/50 dark:bg-muted/50 rounded-lg">
                    <Label className="text-xs font-medium">Name Concatenation</Label>
                    <code className="block text-xs mt-1 text-muted-foreground dark:text-muted-foreground">
                      return concat(first_name, ' ', last_name).toUpperCase()
                    </code>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="font-medium text-foreground dark:text-foreground">Smart Suggestions</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 border border-border dark:border-border rounded-lg">
                    <div>
                      <p className="text-sm font-medium text-foreground dark:text-foreground">Auto-detect phone format</p>
                      <p className="text-xs text-muted-foreground dark:text-muted-foreground">phone → PHONE with formatting</p>
                    </div>
                    <Button size="sm" variant="outline">Apply</Button>
                  </div>
                  <div className="flex items-center justify-between p-3 border border-border dark:border-border rounded-lg">
                    <div>
                      <p className="text-sm font-medium text-foreground dark:text-foreground">Split address fields</p>
                      <p className="text-xs text-muted-foreground dark:text-muted-foreground">address → ADDRESS/STREET, ADDRESS/CITY</p>
                    </div>
                    <Button size="sm" variant="outline">Apply</Button>
                  </div>
                  <div className="flex items-center justify-between p-3 border border-border dark:border-border rounded-lg">
                    <div>
                      <p className="text-sm font-medium text-foreground dark:text-foreground">Standardize names</p>
                      <p className="text-xs text-muted-foreground dark:text-muted-foreground">Convert all names to title case</p>
                    </div>
                    <Button size="sm" variant="outline">Apply</Button>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        )}
      </Card>

      {/* Preview Section */}
      {previewMode && (
        <Card>
          <CardHeader>
            <CardTitle>Transformation Preview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div>
                  <Label className="font-medium">Source Field</Label>
                </div>
                <div>
                  <Label className="font-medium">Sample Input</Label>
                </div>
                <div>
                  <Label className="font-medium">Transformed Output</Label>
                </div>
              </div>
              {generatePreview().map((preview, index) => (
                <div key={index} className="grid grid-cols-1 md:grid-cols-3 gap-4 p-3 border border-border dark:border-border rounded-lg">
                  <div className="font-medium text-foreground dark:text-foreground">
                    {preview.sourceField} → {preview.targetField}
                  </div>
                  <div className="font-mono text-sm bg-muted/50 dark:bg-muted/50 p-2 rounded">
                    {preview.sampleInput}
                  </div>
                  <div className="font-mono text-sm bg-primary/10 dark:bg-primary/10 p-2 rounded">
                    {preview.sampleOutput}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}