import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { 
  Play, 
  Pause, 
  Square, 
  CheckCircle, 
  AlertCircle,
  Clock,
  Database,
  FileText,
  BarChart3,
  Download,
  RefreshCw
} from "lucide-react";

interface ExecutionStep {
  id: string;
  name: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  progress: number;
  message?: string;
  startTime?: Date;
  endTime?: Date;
}

interface ExecutionLog {
  id: string;
  timestamp: Date;
  level: 'info' | 'warning' | 'error' | 'success';
  message: string;
  details?: string;
}

export default function Execute() {
  const [isExecuting, setIsExecuting] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [executionProgress, setExecutionProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState(0);
  const [showLogs, setShowLogs] = useState(true);
  const { toast } = useToast();

  const [executionSteps, setExecutionSteps] = useState<ExecutionStep[]>([
    {
      id: "1",
      name: "Validate CSV Data",
      status: 'pending',
      progress: 0
    },
    {
      id: "2", 
      name: "Apply Field Mappings",
      status: 'pending',
      progress: 0
    },
    {
      id: "3",
      name: "Transform to XML",
      status: 'pending',
      progress: 0
    },
    {
      id: "4",
      name: "Database Connection",
      status: 'pending',
      progress: 0
    },
    {
      id: "5",
      name: "Data Loading",
      status: 'pending',
      progress: 0
    },
    {
      id: "6",
      name: "API Synchronization",
      status: 'pending',
      progress: 0
    }
  ]);

  const [executionLogs, setExecutionLogs] = useState<ExecutionLog[]>([
    {
      id: "1",
      timestamp: new Date(),
      level: 'info',
      message: 'System initialized and ready for execution'
    }
  ]);

  const addLog = (level: ExecutionLog['level'], message: string, details?: string) => {
    const newLog: ExecutionLog = {
      id: Date.now().toString(),
      timestamp: new Date(),
      level,
      message,
      details
    };
    setExecutionLogs(prev => [...prev, newLog]);
  };

  const updateStepStatus = (stepIndex: number, status: ExecutionStep['status'], progress: number, message?: string) => {
    setExecutionSteps(prev => prev.map((step, index) => 
      index === stepIndex 
        ? { 
            ...step, 
            status, 
            progress, 
            message,
            startTime: status === 'running' ? new Date() : step.startTime,
            endTime: status === 'completed' || status === 'failed' ? new Date() : undefined
          }
        : step
    ));
  };

  const simulateExecution = async () => {
    setIsExecuting(true);
    setExecutionProgress(0);
    addLog('info', 'Starting data migration execution...');

    for (let i = 0; i < executionSteps.length; i++) {
      if (isPaused) break;
      
      setCurrentStep(i);
      updateStepStatus(i, 'running', 0);
      addLog('info', `Starting step: ${executionSteps[i].name}`);

      // Simulate step execution with progress
      for (let progress = 0; progress <= 100; progress += 10) {
        if (isPaused) break;
        
        await new Promise(resolve => setTimeout(resolve, 200));
        updateStepStatus(i, 'running', progress);
        setExecutionProgress((i * 100 + progress) / executionSteps.length);
      }

      if (!isPaused) {
        // Simulate occasional failures for demo
        const success = Math.random() > 0.1; // 90% success rate
        
        if (success) {
          updateStepStatus(i, 'completed', 100, 'Step completed successfully');
          addLog('success', `${executionSteps[i].name} completed successfully`);
        } else {
          updateStepStatus(i, 'failed', 0, 'Step failed - see logs for details');
          addLog('error', `${executionSteps[i].name} failed`, 'Connection timeout or validation error');
          break;
        }
      }
    }

    if (!isPaused) {
      setExecutionProgress(100);
      addLog('success', 'Data migration execution completed successfully');
      toast({
        title: "Execution Completed",
        description: "Data migration has been executed successfully.",
      });
    }

    setIsExecuting(false);
  };

  const handleStart = () => {
    simulateExecution();
  };

  const handlePause = () => {
    setIsPaused(!isPaused);
    if (!isPaused) {
      addLog('warning', 'Execution paused by user');
    } else {
      addLog('info', 'Execution resumed by user');
    }
  };

  const handleStop = () => {
    setIsExecuting(false);
    setIsPaused(false);
    setExecutionProgress(0);
    setCurrentStep(0);
    setExecutionSteps(prev => prev.map(step => ({ ...step, status: 'pending' as const, progress: 0 })));
    addLog('warning', 'Execution stopped by user');
  };

  const getStatusIcon = (status: ExecutionStep['status']) => {
    switch (status) {
      case 'running':
        return <RefreshCw className="w-4 h-4 animate-spin text-blue-600" />;
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'failed':
        return <AlertCircle className="w-4 h-4 text-red-600" />;
      default:
        return <Clock className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status: ExecutionStep['status']) => {
    switch (status) {
      case 'running': return 'bg-blue-100 text-blue-700';
      case 'completed': return 'bg-green-100 text-green-700';
      case 'failed': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getLogIcon = (level: ExecutionLog['level']) => {
    switch (level) {
      case 'success': return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'error': return <AlertCircle className="w-4 h-4 text-red-600" />;
      case 'warning': return <AlertCircle className="w-4 h-4 text-yellow-600" />;
      default: return <Clock className="w-4 h-4 text-blue-600" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-foreground dark:text-foreground">Execute Migration</h1>
          <p className="text-muted-foreground dark:text-muted-foreground mt-1">Run the complete data migration process with real-time monitoring</p>
        </div>
        
        <div className="flex space-x-2">
          <Button
            onClick={handleStart}
            disabled={isExecuting}
            className="bg-green-600 hover:bg-green-700"
          >
            <Play className="w-4 h-4 mr-2" />
            Start Execution
          </Button>
          
          {isExecuting && (
            <>
              <Button
                onClick={handlePause}
                variant="outline"
              >
                <Pause className="w-4 h-4 mr-2" />
                {isPaused ? 'Resume' : 'Pause'}
              </Button>
              
              <Button
                onClick={handleStop}
                variant="destructive"
              >
                <Square className="w-4 h-4 mr-2" />
                Stop
              </Button>
            </>
          )}
        </div>
      </div>

      {/* Overall Progress */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center">
              <BarChart3 className="w-5 h-5 mr-2" />
              Execution Progress
            </div>
            <Badge className={isExecuting ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700'}>
              {isExecuting ? (isPaused ? 'Paused' : 'Running') : 'Ready'}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-muted-foreground dark:text-muted-foreground">Overall Progress</span>
                <span className="font-medium text-foreground dark:text-foreground">{Math.round(executionProgress)}%</span>
              </div>
              <Progress value={executionProgress} className="w-full" />
            </div>
            
            {isExecuting && (
              <div className="text-sm text-muted-foreground dark:text-muted-foreground">
                Currently executing: <span className="font-medium text-foreground dark:text-foreground">{executionSteps[currentStep]?.name}</span>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Execution Steps */}
        <Card>
          <CardHeader>
            <CardTitle>Execution Steps</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {executionSteps.map((step, index) => (
                <div key={step.id} className="flex items-center space-x-4 p-3 border border-border dark:border-border rounded-lg">
                  <div className="flex-shrink-0">
                    {getStatusIcon(step.status)}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <h3 className="font-medium text-foreground dark:text-foreground">{step.name}</h3>
                      <Badge className={getStatusColor(step.status)} variant="outline">
                        {step.status}
                      </Badge>
                    </div>
                    
                    {step.status === 'running' && (
                      <div className="space-y-2">
                        <Progress value={step.progress} className="w-full h-2" />
                        <p className="text-xs text-muted-foreground dark:text-muted-foreground">
                          {step.progress}% complete
                        </p>
                      </div>
                    )}
                    
                    {step.message && (
                      <p className="text-xs text-muted-foreground dark:text-muted-foreground mt-1">
                        {step.message}
                      </p>
                    )}
                    
                    {step.endTime && step.startTime && (
                      <p className="text-xs text-muted-foreground dark:text-muted-foreground mt-1">
                        Duration: {Math.round((step.endTime.getTime() - step.startTime.getTime()) / 1000)}s
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Execution Logs */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Execution Logs</span>
              <div className="flex space-x-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setShowLogs(!showLogs)}
                >
                  {showLogs ? 'Hide' : 'Show'} Logs
                </Button>
                <Button size="sm" variant="outline">
                  <Download className="w-4 h-4" />
                </Button>
              </div>
            </CardTitle>
          </CardHeader>
          {showLogs && (
            <CardContent>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {executionLogs.slice(-20).reverse().map((log) => (
                  <div key={log.id} className="flex items-start space-x-3 p-2 rounded-lg hover:bg-muted/50 dark:hover:bg-muted/50">
                    <div className="flex-shrink-0 mt-0.5">
                      {getLogIcon(log.level)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium text-foreground dark:text-foreground">{log.message}</p>
                        <span className="text-xs text-muted-foreground dark:text-muted-foreground">
                          {log.timestamp.toLocaleTimeString()}
                        </span>
                      </div>
                      {log.details && (
                        <p className="text-xs text-muted-foreground dark:text-muted-foreground mt-1">
                          {log.details}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          )}
        </Card>
      </div>

      {/* Configuration Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Execution Configuration Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-3">
              <h3 className="font-medium text-foreground dark:text-foreground flex items-center">
                <FileText className="w-4 h-4 mr-2" />
                Data Source
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground dark:text-muted-foreground">CSV Files:</span>
                  <span className="font-medium text-foreground dark:text-foreground">1 file selected</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground dark:text-muted-foreground">Total Records:</span>
                  <span className="font-medium text-foreground dark:text-foreground">~1,250 rows</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground dark:text-muted-foreground">Field Mappings:</span>
                  <span className="font-medium text-foreground dark:text-foreground">12 configured</span>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h3 className="font-medium text-foreground dark:text-foreground flex items-center">
                <Database className="w-4 h-4 mr-2" />
                Target Systems
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground dark:text-muted-foreground">Databases:</span>
                  <span className="font-medium text-foreground dark:text-foreground">3 configured</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground dark:text-muted-foreground">REST APIs:</span>
                  <span className="font-medium text-foreground dark:text-foreground">2 configured</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground dark:text-muted-foreground">Batch Size:</span>
                  <span className="font-medium text-foreground dark:text-foreground">100 records</span>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h3 className="font-medium text-foreground dark:text-foreground flex items-center">
                <BarChart3 className="w-4 h-4 mr-2" />
                Execution Settings
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground dark:text-muted-foreground">Parallel Processing:</span>
                  <span className="font-medium text-foreground dark:text-foreground">Enabled</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground dark:text-muted-foreground">Error Handling:</span>
                  <span className="font-medium text-foreground dark:text-foreground">Continue on Error</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground dark:text-muted-foreground">Retry Attempts:</span>
                  <span className="font-medium text-foreground dark:text-foreground">3 times</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}