import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { HelpCircle, FileText, Video, MessageCircle, Mail } from "lucide-react";

export default function Help() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Help & Support</h1>
        <p className="text-gray-600 mt-1">Get help with TCS Data Migration for OpenText InfoArchive</p>
      </div>

      {/* Quick Help Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-4 text-center hover:shadow-md transition-shadow cursor-pointer">
          <FileText className="w-8 h-8 text-blue-600 mx-auto mb-2" />
          <h3 className="font-medium text-gray-900">Documentation</h3>
          <p className="text-sm text-gray-500">Complete user guide</p>
        </Card>
        
        <Card className="p-4 text-center hover:shadow-md transition-shadow cursor-pointer">
          <Video className="w-8 h-8 text-green-600 mx-auto mb-2" />
          <h3 className="font-medium text-gray-900">Video Tutorials</h3>
          <p className="text-sm text-gray-500">Step-by-step guides</p>
        </Card>
        
        <Card className="p-4 text-center hover:shadow-md transition-shadow cursor-pointer">
          <MessageCircle className="w-8 h-8 text-purple-600 mx-auto mb-2" />
          <h3 className="font-medium text-gray-900">Community</h3>
          <p className="text-sm text-gray-500">Ask questions</p>
        </Card>
        
        <Card className="p-4 text-center hover:shadow-md transition-shadow cursor-pointer">
          <Mail className="w-8 h-8 text-orange-600 mx-auto mb-2" />
          <h3 className="font-medium text-gray-900">Contact Support</h3>
          <p className="text-sm text-gray-500">Get direct help</p>
        </Card>
      </div>

      {/* Getting Started Guide */}
      <Card>
        <CardHeader>
          <CardTitle>Getting Started</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-start space-x-4">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-sm font-medium text-blue-600">1</span>
              </div>
              <div>
                <h3 className="font-medium text-gray-900">Upload Your CSV File</h3>
                <p className="text-sm text-gray-600">Navigate to CSV Upload and select your data file. Supported formats include CSV, TSV, and Excel files.</p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-sm font-medium text-blue-600">2</span>
              </div>
              <div>
                <h3 className="font-medium text-gray-900">Configure XML Transformation</h3>
                <p className="text-sm text-gray-600">Set up your XML transformation rules to convert CSV data into the required TICKETS/CUSTOMER/EDITOR/BOW hierarchy.</p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-sm font-medium text-blue-600">3</span>
              </div>
              <div>
                <h3 className="font-medium text-gray-900">Setup Database Connections</h3>
                <p className="text-sm text-gray-600">Configure your target database connections including PostgreSQL, Oracle, MongoDB, or Microsoft SQL Server.</p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-sm font-medium text-blue-600">4</span>
              </div>
              <div>
                <h3 className="font-medium text-gray-900">Execute Migration</h3>
                <p className="text-sm text-gray-600">Run the complete migration process and monitor progress through the dashboard.</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* FAQ Section */}
      <Card>
        <CardHeader>
          <CardTitle>Frequently Asked Questions</CardTitle>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-1">
              <AccordionTrigger>What file formats are supported for upload?</AccordionTrigger>
              <AccordionContent>
                The platform supports CSV, TSV, and Excel files (.xlsx, .xls). Files can be up to 10MB in size. 
                Make sure your data includes proper headers and follows standard formatting conventions.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-2">
              <AccordionTrigger>How does the XML transformation work?</AccordionTrigger>
              <AccordionContent>
                The XML transformation converts your CSV data into a structured XML format following the 
                TICKETS/CUSTOMER/EDITOR/BOW hierarchy. You can customize transformation rules and handle 
                special characters encoding automatically.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-3">
              <AccordionTrigger>Which databases are supported?</AccordionTrigger>
              <AccordionContent>
                Currently supported databases include PostgreSQL (12.x+), Oracle (19c+), MongoDB (5.0+), 
                and Microsoft SQL Server (2019+). Each database connection can be configured with custom 
                connection parameters and credentials.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-4">
              <AccordionTrigger>How can I monitor the migration progress?</AccordionTrigger>
              <AccordionContent>
                The dashboard provides real-time monitoring of all migration processes including success rates, 
                active configurations, and detailed logs. You can also set up notifications for completed 
                or failed operations.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-5">
              <AccordionTrigger>What should I do if a migration fails?</AccordionTrigger>
              <AccordionContent>
                If a migration fails, check the error logs in the Recent Activity section. Common issues include 
                database connection problems, invalid data formats, or permission issues. The system provides 
                detailed error messages to help diagnose and resolve problems.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* Contact Support */}
      <Card>
        <CardHeader>
          <CardTitle>Need More Help?</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-medium text-gray-900 mb-3">Contact Information</h3>
              <div className="space-y-2 text-sm text-gray-600">
                <p><strong>Email:</strong> support@tcs.com</p>
                <p><strong>Phone:</strong> +1 (800) 123-4567</p>
                <p><strong>Hours:</strong> Mon-Fri 9:00 AM - 6:00 PM EST</p>
              </div>
            </div>
            
            <div>
              <h3 className="font-medium text-gray-900 mb-3">Additional Resources</h3>
              <div className="space-y-2">
                <Button variant="outline" className="w-full justify-start">
                  <FileText className="w-4 h-4 mr-2" />
                  Download User Manual
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Video className="w-4 h-4 mr-2" />
                  Watch Training Videos
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Join Community Forum
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
