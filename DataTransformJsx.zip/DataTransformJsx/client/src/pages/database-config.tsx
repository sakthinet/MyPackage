import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { ProcessFlow } from "@/components/process-flow";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { 
  Database, 
  Plus, 
  Edit, 
  Trash2, 
  TestTube,
  CheckCircle,
  XCircle,
  Server
} from "lucide-react";
import type { DatabaseConfig, InsertDatabaseConfig } from "@shared/schema";
import { insertDatabaseConfigSchema } from "@shared/schema";

export default function DatabaseConfig() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [testingConnection, setTestingConnection] = useState<number | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();

  const { data: configs, isLoading } = useQuery<DatabaseConfig[]>({
    queryKey: ["/api/database-configs"],
  });

  const form = useForm<InsertDatabaseConfig>({
    resolver: zodResolver(insertDatabaseConfigSchema),
    defaultValues: {
      name: "",
      type: "postgresql",
      host: "localhost",
      port: 5432,
      database: "",
      username: "",
      password: "",
      isActive: true,
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertDatabaseConfig): Promise<DatabaseConfig> => {
      const response = await fetch('/api/database-configs', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        throw new Error(`Create failed: ${response.statusText}`);
      }
      
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/database-configs"] });
      setDialogOpen(false);
      form.reset();
      toast({
        title: "Database configuration created",
        description: "Your database configuration has been successfully added.",
      });
    },
    onError: () => {
      toast({
        title: "Failed to create configuration",
        description: "There was an error creating the database configuration.",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/database-configs/${id}`, {
        method: 'DELETE',
      });
      
      if (!response.ok) {
        throw new Error(`Delete failed: ${response.statusText}`);
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/database-configs"] });
      toast({
        title: "Configuration deleted",
        description: "The database configuration has been successfully deleted.",
      });
    },
    onError: () => {
      toast({
        title: "Delete failed",
        description: "There was an error deleting the configuration.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (data: InsertDatabaseConfig) => {
    createMutation.mutate(data);
  };

  const handleTestConnection = async (config: DatabaseConfig) => {
    setTestingConnection(config.id);
    
    // Simulate connection test
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setTestingConnection(null);
    
    // Random success/failure for demo
    const success = Math.random() > 0.3;
    
    if (success) {
      toast({
        title: "Connection successful",
        description: `Successfully connected to ${config.name}`,
      });
    } else {
      toast({
        title: "Connection failed",
        description: `Failed to connect to ${config.name}. Please check your configuration.`,
        variant: "destructive",
      });
    }
  };

  const getDatabaseIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'postgresql':
        return 'bg-blue-100 text-blue-600';
      case 'mongodb':
        return 'bg-green-100 text-green-600';
      case 'oracle':
        return 'bg-red-100 text-red-600';
      case 'mysql':
        return 'bg-orange-100 text-orange-600';
      default:
        return 'bg-gray-100 text-gray-600';
    }
  };

  const getDefaultPort = (type: string) => {
    switch (type) {
      case 'postgresql': return 5432;
      case 'mysql': return 3306;
      case 'mongodb': return 27017;
      case 'oracle': return 1521;
      case 'mssql': return 1433;
      default: return 5432;
    }
  };

  // Update port when database type changes
  const handleTypeChange = (type: string) => {
    form.setValue('type', type);
    form.setValue('port', getDefaultPort(type));
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Database Configuration</h1>
          <p className="text-gray-600 mt-1">Configure connections to your target database systems</p>
        </div>
        
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-purple-600 hover:bg-purple-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Database
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Add Database Configuration</DialogTitle>
            </DialogHeader>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Configuration Name</Label>
                <Input
                  id="name"
                  placeholder="e.g., Production Database"
                  {...form.register('name')}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="type">Database Type</Label>
                <Select
                  value={form.watch('type')}
                  onValueChange={handleTypeChange}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select database type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="postgresql">PostgreSQL</SelectItem>
                    <SelectItem value="mysql">MySQL</SelectItem>
                    <SelectItem value="mongodb">MongoDB</SelectItem>
                    <SelectItem value="oracle">Oracle</SelectItem>
                    <SelectItem value="mssql">Microsoft SQL Server</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="host">Host</Label>
                  <Input
                    id="host"
                    placeholder="localhost"
                    {...form.register('host')}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="port">Port</Label>
                  <Input
                    id="port"
                    type="number"
                    {...form.register('port', { valueAsNumber: true })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="database">Database Name</Label>
                <Input
                  id="database"
                  placeholder="database_name"
                  {...form.register('database')}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="username">Username</Label>
                  <Input
                    id="username"
                    placeholder="username"
                    {...form.register('username')}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="password"
                    {...form.register('password')}
                  />
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  id="isActive"
                  checked={form.watch('isActive') || false}
                  onCheckedChange={(checked) => form.setValue('isActive', checked || false)}
                />
                <Label htmlFor="isActive">Set as active configuration</Label>
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={createMutation.isPending}>
                  {createMutation.isPending ? 'Creating...' : 'Create Configuration'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Database Configurations */}
      <Card>
        <CardHeader>
          <CardTitle>Database Connections</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="animate-pulse flex items-center space-x-4">
                    <div className="w-12 h-12 bg-gray-200 rounded-lg"></div>
                    <div>
                      <div className="h-4 bg-gray-200 rounded w-32 mb-2"></div>
                      <div className="h-3 bg-gray-200 rounded w-48"></div>
                    </div>
                  </div>
                  <div className="w-20 h-8 bg-gray-200 rounded"></div>
                </div>
              ))}
            </div>
          ) : configs && configs.length > 0 ? (
            <div className="space-y-4">
              {configs.map((config) => (
                <div key={config.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                  <div className="flex items-center space-x-4">
                    <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${getDatabaseIcon(config.type)}`}>
                      <Database className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900">{config.name}</h3>
                      <div className="flex items-center space-x-2 text-sm text-gray-500">
                        <span className="font-medium">{config.type.toUpperCase()}</span>
                        <span>•</span>
                        <span>{config.host}:{config.port}</span>
                        <span>•</span>
                        <span>DB: {config.database}</span>
                      </div>
                      <p className="text-xs text-gray-400">
                        Created {config.createdAt ? new Date(String(config.createdAt)).toLocaleDateString() : 'Unknown'}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <Badge variant={config.isActive ? "default" : "secondary"}>
                      {config.isActive ? (
                        <>
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Active
                        </>
                      ) : (
                        <>
                          <XCircle className="w-3 h-3 mr-1" />
                          Inactive
                        </>
                      )}
                    </Badge>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleTestConnection(config)}
                      disabled={testingConnection === config.id}
                    >
                      <TestTube className={`w-4 h-4 ${testingConnection === config.id ? 'animate-spin' : ''}`} />
                    </Button>
                    
                    <Button variant="outline" size="sm">
                      <Edit className="w-4 h-4" />
                    </Button>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => deleteMutation.mutate(config.id)}
                      disabled={deleteMutation.isPending}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Server className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500 mb-2">No database configurations found</p>
              <p className="text-sm text-gray-400">Add your first database configuration to get started</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Connection Guidelines */}
      <Card>
        <CardHeader>
          <CardTitle>Database Connection Guidelines</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-medium text-gray-900 mb-3">Supported Database Systems</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                  PostgreSQL 12.x and later
                </li>
                <li className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                  MySQL 8.0 and later
                </li>
                <li className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                  MongoDB 5.0 and later
                </li>
                <li className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                  Oracle 19c and later
                </li>
                <li className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                  Microsoft SQL Server 2019+
                </li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-medium text-gray-900 mb-3">Connection Requirements</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Database user must have CREATE, INSERT, UPDATE permissions</li>
                <li>• Network connectivity to database host</li>
                <li>• Proper firewall configuration</li>
                <li>• SSL/TLS encryption recommended for production</li>
                <li>• Connection pooling for high-volume operations</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
