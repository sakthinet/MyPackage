import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { FieldDetector, type FieldInfo } from "@/lib/field-detector";
import { 
  CheckCircle, 
  AlertCircle, 
  FileText, 
  Zap,
  Eye,
  EyeOff
} from "lucide-react";

interface FieldTypeDetectorProps {
  csvData: string[][];
  onFieldsDetected?: (fields: FieldInfo[]) => void;
  isVisible?: boolean;
}

export function FieldTypeDetector({ csvData, onFieldsDetected, isVisible = true }: FieldTypeDetectorProps) {
  const [detectedFields, setDetectedFields] = useState<FieldInfo[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showDetails, setShowDetails] = useState(false);

  useEffect(() => {
    if (csvData.length > 0 && isVisible) {
      analyzeFields();
    }
  }, [csvData, isVisible]);

  const analyzeFields = async () => {
    setIsAnalyzing(true);
    
    // Simulate analysis delay for UX
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const fields = FieldDetector.detectFieldTypes(csvData);
    setDetectedFields(fields);
    setIsAnalyzing(false);
    
    if (onFieldsDetected) {
      onFieldsDetected(fields);
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.9) return "text-green-600 dark:text-green-400";
    if (confidence >= 0.7) return "text-yellow-600 dark:text-yellow-400";
    return "text-red-600 dark:text-red-400";
  };

  const getConfidenceLabel = (confidence: number) => {
    if (confidence >= 0.9) return "High";
    if (confidence >= 0.7) return "Medium";
    return "Low";
  };

  if (!isVisible) return null;

  return (
    <Card className="mt-4">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Zap className="w-5 h-5 text-primary" />
            <CardTitle className="text-lg">Smart Field Type Detection</CardTitle>
          </div>
          {detectedFields.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowDetails(!showDetails)}
              className="text-muted-foreground"
            >
              {showDetails ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              {showDetails ? 'Hide' : 'Show'} Details
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {isAnalyzing ? (
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary"></div>
              <span className="text-sm text-muted-foreground">Analyzing field types...</span>
            </div>
            <Progress value={75} className="w-full" />
          </div>
        ) : detectedFields.length > 0 ? (
          <div className="space-y-4">
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <CheckCircle className="w-4 h-4 text-green-500" />
              <span>Detected {detectedFields.length} fields with automatic type inference</span>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {detectedFields.map((field, index) => (
                <div
                  key={index}
                  className="p-3 border border-border dark:border-border rounded-lg bg-muted/30 dark:bg-muted/30"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <span className="text-lg">{FieldDetector.getFieldTypeIcon(field.type)}</span>
                      <span className="font-medium text-sm truncate max-w-24" title={field.name}>
                        {field.name}
                      </span>
                    </div>
                    <Badge 
                      variant="secondary" 
                      className={`text-xs ${FieldDetector.getFieldTypeColor(field.type)}`}
                    >
                      {field.type}
                    </Badge>
                  </div>
                  
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="text-muted-foreground">Confidence:</span>
                      <span className={getConfidenceColor(field.confidence)}>
                        {getConfidenceLabel(field.confidence)} ({Math.round(field.confidence * 100)}%)
                      </span>
                    </div>
                    
                    {field.format && (
                      <div className="text-xs text-muted-foreground">
                        Format: {field.format}
                      </div>
                    )}
                    
                    <div className="text-xs text-muted-foreground">
                      {field.uniqueValues}/{field.totalValues} unique
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {showDetails && (
              <>
                <Separator />
                <div className="space-y-4">
                  <h4 className="text-sm font-medium">Field Analysis Details</h4>
                  <div className="space-y-3">
                    {detectedFields.map((field, index) => (
                      <div key={index} className="p-3 bg-muted/20 dark:bg-muted/20 rounded">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium">{field.name}</span>
                          <Badge variant="outline" className="text-xs">
                            {field.type}
                          </Badge>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="text-muted-foreground">Sample values:</span>
                            <div className="mt-1 space-y-1">
                              {field.samples.slice(0, 3).map((sample, i) => (
                                <div key={i} className="text-xs font-mono bg-background dark:bg-background p-1 rounded">
                                  {sample || '<empty>'}
                                </div>
                              ))}
                            </div>
                          </div>
                          
                          <div className="space-y-1">
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Nullable:</span>
                              <span>{field.nullable ? 'Yes' : 'No'}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Unique:</span>
                              <span>{field.uniqueValues}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Total:</span>
                              <span>{field.totalValues}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}

            <div className="flex items-center space-x-4 text-xs text-muted-foreground">
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span>High confidence (≥90%)</span>
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                <span>Medium confidence (70-89%)</span>
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                <span>Low confidence (&lt;70%)</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="text-center py-8">
            <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Upload a CSV file to automatically detect field types</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}