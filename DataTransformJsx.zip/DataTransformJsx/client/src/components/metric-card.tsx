import { LucideIcon } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface MetricCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  iconBgColor: string;
  iconColor: string;
  change?: string;
  changeType?: "positive" | "negative" | "neutral";
  subtitle?: string;
}

export function MetricCard({
  title,
  value,
  icon: Icon,
  iconBgColor,
  iconColor,
  change,
  changeType = "neutral",
  subtitle
}: MetricCardProps) {
  return (
    <Card className="p-6">
      <CardContent className="p-0">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-medium text-gray-600">{title}</h3>
          <div className={`w-10 h-10 ${iconBgColor} rounded-lg flex items-center justify-center`}>
            <Icon className={`w-5 h-5 ${iconColor}`} />
          </div>
        </div>
        
        <div className="flex items-baseline mb-2">
          <span className="text-3xl font-bold text-gray-900">{value}</span>
        </div>
        
        {change && (
          <p className={`text-sm ${
            changeType === "positive" ? "text-green-600" : 
            changeType === "negative" ? "text-red-600" : 
            "text-gray-600"
          }`}>
            {change}
          </p>
        )}
        
        {subtitle && (
          <p className="text-sm text-gray-600 mt-2">{subtitle}</p>
        )}
      </CardContent>
    </Card>
  );
}
