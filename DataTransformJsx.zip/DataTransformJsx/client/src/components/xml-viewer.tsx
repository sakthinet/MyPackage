import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Copy, Download, Eye, EyeOff, Code2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface XmlViewerProps {
  xmlContent: string;
  title?: string;
  recordCount?: number;
}

export function XmlViewer({ xmlContent, title = "XML Preview", recordCount }: XmlViewerProps) {
  const [showRaw, setShowRaw] = useState(false);
  const { toast } = useToast();

  const formatXml = (xml: string): string => {
    const PADDING = '  ';
    let formatted = '';
    let indent = 0;
    
    xml.split(/>\s*</).forEach((node, i) => {
      if (i > 0) formatted += '<';
      
      if (node.match(/^\/\w/)) {
        indent--;
      }
      
      formatted += PADDING.repeat(indent) + node;
      
      if (node.match(/^<?\w[^>]*[^\/]$/)) {
        indent++;
      }
      
      if (i < xml.split(/>\s*</).length - 1) {
        formatted += '>\n';
      }
    });
    
    return formatted;
  };

  const syntaxHighlight = (xml: string): string => {
    return xml
      // XML declaration and processing instructions
      .replace(/(&lt;\?xml.*?\?&gt;)/g, '<span style="color: #e879f9;">$1</span>')
      // Comments
      .replace(/(&lt;!--.*?--&gt;)/g, '<span style="color: #64748b;">$1</span>')
      // Opening tags
      .replace(/(&lt;)([a-zA-Z_][a-zA-Z0-9_]*)([^&gt;]*?)(&gt;)/g, 
        '<span style="color: #06b6d4;">$1</span><span style="color: #f59e0b;">$2</span><span style="color: #10b981;">$3</span><span style="color: #06b6d4;">$4</span>')
      // Closing tags
      .replace(/(&lt;\/)([a-zA-Z_][a-zA-Z0-9_]*)(&gt;)/g, 
        '<span style="color: #06b6d4;">$1</span><span style="color: #f59e0b;">$2</span><span style="color: #06b6d4;">$3</span>')
      // Text content between tags
      .replace(/(&gt;)([^&lt;]+)(&lt;)/g, '$1<span style="color: #e5e7eb;">$2</span>$3')
      // Attributes
      .replace(/(\w+)(=)(".*?")/g, '<span style="color: #8b5cf6;">$1</span><span style="color: #06b6d4;">$2</span><span style="color: #22c55e;">$3</span>');
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(xmlContent);
    toast({
      title: "XML copied",
      description: "The XML content has been copied to your clipboard.",
    });
  };

  const handleDownload = () => {
    const blob = new Blob([xmlContent], { type: 'application/xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'transformed-data.xml';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "XML downloaded",
      description: "The XML file has been downloaded successfully.",
    });
  };

  const processedXml = xmlContent
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');

  const highlightedXml = syntaxHighlight(processedXml);
  const formattedXml = formatXml(processedXml);

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Code2 className="w-5 h-5 text-primary" />
            <CardTitle className="text-lg">{title}</CardTitle>
          </div>
          <div className="flex items-center space-x-2">
            {recordCount && (
              <Badge variant="secondary" className="bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300">
                {recordCount} records
              </Badge>
            )}
            <Badge variant="secondary" className="bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300">
              {Math.round(xmlContent.length / 1024)}KB
            </Badge>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowRaw(!showRaw)}
              className="text-muted-foreground"
            >
              {showRaw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              {showRaw ? 'Formatted' : 'Raw'}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleCopy}
              className="text-muted-foreground"
            >
              <Copy className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleDownload}
              className="text-muted-foreground"
            >
              <Download className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="relative">
          <div className="bg-slate-950 dark:bg-slate-950 border border-slate-700 dark:border-slate-700 rounded-lg p-4 overflow-auto max-h-96">
            {showRaw ? (
              <pre className="text-sm text-green-400 dark:text-green-400 font-mono whitespace-pre-wrap">
                {xmlContent}
              </pre>
            ) : (
              <pre 
                className="text-sm font-mono whitespace-pre-wrap leading-relaxed"
                dangerouslySetInnerHTML={{ 
                  __html: syntaxHighlight(formatXml(processedXml))
                }}
              />
            )}
          </div>
          
          <div className="absolute top-2 right-2 flex space-x-1">
            <Badge className="bg-slate-800 text-slate-300 text-xs">
              XML
            </Badge>
            <Badge className="bg-blue-900 text-blue-200 text-xs">
              UTF-8
            </Badge>
            <Badge className="bg-purple-900 text-purple-200 text-xs">
              TICKETS/CUSTOMER08
            </Badge>
          </div>
        </div>
        
        <div className="mt-4 flex items-center justify-between text-xs text-muted-foreground">
          <span>TICKETS → CUSTOMER08 → ROW structure</span>
          <span>Special characters XML-encoded</span>
        </div>
      </CardContent>
    </Card>
  );
}