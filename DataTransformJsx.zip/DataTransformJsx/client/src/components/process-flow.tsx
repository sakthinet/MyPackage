import { CheckCircle, Circle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

interface ProcessStep {
  id: number;
  title: string;
  path: string;
  completed: boolean;
  current: boolean;
}

interface ProcessFlowProps {
  currentStep: number;
  onNext?: () => void;
  showNextButton?: boolean;
}

export function ProcessFlow({ currentStep, onNext, showNextButton = false }: ProcessFlowProps) {
  const [, setLocation] = useLocation();

  const steps: ProcessStep[] = [
    { id: 1, title: "CSV Upload", path: "/csv-upload", completed: currentStep > 1, current: currentStep === 1 },
    { id: 2, title: "XML Transform", path: "/xml-transform", completed: currentStep > 2, current: currentStep === 2 },
    { id: 3, title: "Database Config", path: "/database-config", completed: currentStep > 3, current: currentStep === 3 },
    { id: 4, title: "REST API Config", path: "/rest-api-config", completed: currentStep > 4, current: currentStep === 4 },
    { id: 5, title: "Field Mapping", path: "/field-mapping", completed: currentStep > 5, current: currentStep === 5 },
    { id: 6, title: "Execution", path: "/execute", completed: currentStep > 6, current: currentStep === 6 },
  ];

  const handleStepClick = (step: ProcessStep) => {
    if (step.completed || step.current) {
      setLocation(step.path);
    }
  };

  return (
    <div className="bg-card dark:bg-card border border-border dark:border-border rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold text-foreground dark:text-foreground">
            Step {currentStep}: {steps[currentStep - 1]?.title}
          </h2>
          <p className="text-sm text-muted-foreground dark:text-muted-foreground">
            Data transformation process workflow
          </p>
        </div>
        {showNextButton && onNext && (
          <Button onClick={onNext} className="bg-primary hover:bg-primary/90">
            Next →
          </Button>
        )}
      </div>

      <div className="flex items-center space-x-4 overflow-x-auto pb-2">
        {steps.map((step, index) => (
          <div key={step.id} className="flex items-center space-x-4 flex-shrink-0">
            <div
              className={`flex items-center space-x-3 px-4 py-2 rounded-lg cursor-pointer transition-colors ${
                step.current
                  ? "bg-primary/10 dark:bg-primary/20 border border-primary dark:border-primary"
                  : step.completed
                  ? "bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 hover:bg-green-100 dark:hover:bg-green-900/30"
                  : "bg-muted/50 dark:bg-muted/50 border border-border dark:border-border opacity-60"
              }`}
              onClick={() => handleStepClick(step)}
            >
              <div
                className={`flex items-center justify-center w-8 h-8 rounded-full text-sm font-medium ${
                  step.current
                    ? "bg-primary text-primary-foreground"
                    : step.completed
                    ? "bg-green-500 text-white"
                    : "bg-muted dark:bg-muted text-muted-foreground dark:text-muted-foreground"
                }`}
              >
                {step.completed ? (
                  <CheckCircle className="w-5 h-5" />
                ) : (
                  <span>{step.id}</span>
                )}
              </div>
              <div className="text-left">
                <div className={`text-sm font-medium ${
                  step.current 
                    ? "text-primary dark:text-primary" 
                    : step.completed 
                    ? "text-green-700 dark:text-green-300" 
                    : "text-muted-foreground dark:text-muted-foreground"
                }`}>
                  {step.title}
                </div>
              </div>
            </div>
            
            {index < steps.length - 1 && (
              <div className={`w-8 h-0.5 ${
                step.completed ? "bg-green-400 dark:bg-green-600" : "bg-border dark:bg-border"
              }`} />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}