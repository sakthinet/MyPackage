import { useState } from "react";
import { Link, useLocation } from "wouter";
import { 
  Database, 
  Gauge, 
  Settings, 
  Info, 
  HelpCircle, 
  ChevronDown,
  Upload,
  Code,
  Server,
  Plug,
  Shuffle,
  Play
} from "lucide-react";
import { cn } from "@/lib/utils";

const navigationItems = [
  { href: "/", label: "Dashboard", icon: Gauge },
  { href: "/configurations", label: "Configurations", icon: Settings },
  { href: "/about", label: "About", icon: Info },
  { href: "/help", label: "Help", icon: HelpCircle },
];

const workflowSteps = [
  { href: "/csv-upload", label: "1. CSV Upload", icon: Upload },
  { href: "/xml-transform", label: "2. XML Transform", icon: Code },
  { href: "/database-config", label: "3. Database Config", icon: Database },
  { href: "/rest-api-config", label: "4. REST API Config", icon: Plug },
  { href: "/field-mapping", label: "5. Field Mapping", icon: Shuffle },
  { href: "/execute", label: "6. Execute", icon: Play },
];

export function Sidebar() {
  const [location] = useLocation();
  const [workflowExpanded, setWorkflowExpanded] = useState(true);

  return (
    <div className="w-64 bg-sidebar dark:bg-sidebar text-white flex flex-col border-r border-border dark:border-border">
      {/* Logo and Title */}
      <div className="p-6 border-b border-gray-700 dark:border-gray-600">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary dark:bg-primary rounded-lg flex items-center justify-center">
            <Database className="w-4 h-4 text-primary-foreground dark:text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-sm font-semibold text-white dark:text-white">TCS Data Migration</h1>
            <p className="text-xs text-gray-400 dark:text-gray-300">OpenText InfoArchive</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-4 py-6 space-y-2">
        {navigationItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.href;
          
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors",
                isActive
                  ? "bg-primary dark:bg-primary text-primary-foreground dark:text-primary-foreground"
                  : "text-gray-300 dark:text-gray-300 hover:bg-gray-700 dark:hover:bg-gray-600 hover:text-white dark:hover:text-white"
              )}
            >
              <Icon className="w-5 h-5" />
              <span className="text-sm font-medium">{item.label}</span>
            </Link>
          );
        })}

        {/* Process Workflow */}
        <div className="pt-4">
          <button
            onClick={() => setWorkflowExpanded(!workflowExpanded)}
            className="w-full flex items-center justify-between px-3 py-2 text-gray-300 dark:text-gray-300 hover:bg-gray-700 dark:hover:bg-gray-600 hover:text-white dark:hover:text-white rounded-lg transition-colors"
          >
            <div className="flex items-center space-x-3">
              <Server className="w-5 h-5" />
              <span className="text-sm font-medium">Process Workflow</span>
            </div>
            <ChevronDown
              className={cn(
                "w-4 h-4 transition-transform",
                workflowExpanded ? "rotate-180" : ""
              )}
            />
          </button>

          {workflowExpanded && (
            <div className="ml-6 mt-2 space-y-1">
              {workflowSteps.map((step) => {
                const Icon = step.icon;
                const isActive = location === step.href;

                return (
                  <Link
                    key={step.href}
                    href={step.href}
                    className={cn(
                      "flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors text-sm",
                      isActive
                        ? "bg-primary dark:bg-primary text-primary-foreground dark:text-primary-foreground"
                        : "text-gray-400 dark:text-gray-400 hover:bg-gray-700 dark:hover:bg-gray-600 hover:text-white dark:hover:text-white"
                    )}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{step.label}</span>
                  </Link>
                );
              })}
            </div>
          )}
        </div>
      </nav>
    </div>
  );
}
