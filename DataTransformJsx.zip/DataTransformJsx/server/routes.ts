import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import path from "path";
import fs from "fs";
import { insertTransformationSchema, insertDatabaseConfigSchema, insertCsvFileSchema } from "@shared/schema";

// Configure multer for file uploads
const uploadDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const upload = multer({
  dest: uploadDir,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['.csv', '.tsv', '.xlsx', '.xls'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowedTypes.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only CSV, TSV, and Excel files are allowed.'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Dashboard metrics
  app.get("/api/dashboard/metrics", async (req, res) => {
    try {
      const metrics = await storage.getDashboardMetrics();
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard metrics" });
    }
  });

  // CSV file upload
  app.post("/api/csv/upload", upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const csvFile = await storage.createCsvFile({
        originalName: req.file.originalname,
        fileName: req.file.filename,
        filePath: req.file.path,
        size: req.file.size,
        mimeType: req.file.mimetype
      });

      res.json(csvFile);
    } catch (error) {
      res.status(500).json({ message: "Failed to upload file" });
    }
  });

  // Get all CSV files
  app.get("/api/csv/files", async (req, res) => {
    try {
      const files = await storage.getCsvFiles();
      res.json(files);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch CSV files" });
    }
  });

  // Delete CSV file
  app.delete("/api/csv/files/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const file = await storage.getCsvFile(id);
      
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }

      // Delete physical file
      if (fs.existsSync(file.filePath)) {
        fs.unlinkSync(file.filePath);
      }

      const deleted = await storage.deleteCsvFile(id);
      if (deleted) {
        res.json({ message: "File deleted successfully" });
      } else {
        res.status(404).json({ message: "File not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to delete file" });
    }
  });

  // Transformations
  app.get("/api/transformations", async (req, res) => {
    try {
      const transformations = await storage.getTransformations();
      res.json(transformations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch transformations" });
    }
  });

  app.post("/api/transformations", async (req, res) => {
    try {
      const validatedData = insertTransformationSchema.parse(req.body);
      const transformation = await storage.createTransformation(validatedData);
      res.json(transformation);
    } catch (error) {
      res.status(400).json({ message: "Invalid transformation data" });
    }
  });

  app.put("/api/transformations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertTransformationSchema.partial().parse(req.body);
      const transformation = await storage.updateTransformation(id, validatedData);
      
      if (!transformation) {
        return res.status(404).json({ message: "Transformation not found" });
      }
      
      res.json(transformation);
    } catch (error) {
      res.status(400).json({ message: "Invalid transformation data" });
    }
  });

  app.delete("/api/transformations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteTransformation(id);
      
      if (deleted) {
        res.json({ message: "Transformation deleted successfully" });
      } else {
        res.status(404).json({ message: "Transformation not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to delete transformation" });
    }
  });

  // Database configurations
  app.get("/api/database-configs", async (req, res) => {
    try {
      const configs = await storage.getDatabaseConfigs();
      res.json(configs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch database configurations" });
    }
  });

  app.post("/api/database-configs", async (req, res) => {
    try {
      const validatedData = insertDatabaseConfigSchema.parse(req.body);
      const config = await storage.createDatabaseConfig(validatedData);
      res.json(config);
    } catch (error) {
      res.status(400).json({ message: "Invalid database configuration data" });
    }
  });

  app.put("/api/database-configs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertDatabaseConfigSchema.partial().parse(req.body);
      const config = await storage.updateDatabaseConfig(id, validatedData);
      
      if (!config) {
        return res.status(404).json({ message: "Database configuration not found" });
      }
      
      res.json(config);
    } catch (error) {
      res.status(400).json({ message: "Invalid database configuration data" });
    }
  });

  app.delete("/api/database-configs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteDatabaseConfig(id);
      
      if (deleted) {
        res.json({ message: "Database configuration deleted successfully" });
      } else {
        res.status(404).json({ message: "Database configuration not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to delete database configuration" });
    }
  });

  // XML Transformation endpoint
  app.post("/api/xml/transform", async (req, res) => {
    try {
      const { csvFileId, transformationConfig } = req.body;
      
      if (!csvFileId) {
        return res.status(400).json({ message: "CSV file ID is required" });
      }

      const csvFile = await storage.getCsvFile(csvFileId);
      if (!csvFile) {
        return res.status(404).json({ message: "CSV file not found" });
      }

      // Read and parse the CSV file
      let csvData = '';
      try {
        csvData = fs.readFileSync(csvFile.filePath, 'utf8');
      } catch (error) {
        return res.status(500).json({ message: "Failed to read CSV file" });
      }

      // Parse CSV content with proper handling of quoted fields
      const lines = csvData.split('\n').filter(line => line.trim());
      const headers = lines[0].split(',').map(h => h.trim());
      
      const parseCSVLine = (line: string): string[] => {
        const result: string[] = [];
        let current = '';
        let inQuotes = false;
        
        for (let i = 0; i < line.length; i++) {
          const char = line[i];
          
          if (char === '"') {
            if (inQuotes && line[i + 1] === '"') {
              current += '"';
              i++; // skip next quote
            } else {
              inQuotes = !inQuotes;
            }
          } else if (char === ',' && !inQuotes) {
            result.push(current.trim());
            current = '';
          } else {
            current += char;
          }
        }
        result.push(current.trim());
        return result;
      };

      const rows = lines.slice(1).map(line => {
        const values = parseCSVLine(line);
        const row: any = {};
        headers.forEach((header, index) => {
          row[header] = values[index] || '';
        });
        return row;
      }).filter(row => Object.values(row).some(val => val !== ''));

      // Generate XML with actual data in TICKETS/CUSTOMER08 format
      let xmlContent = `<?xml version="1.0" encoding="UTF-8"?>
<TICKETS>
  <CUSTOMER08>`;

      rows.forEach((row, index) => {
        xmlContent += `
    <ROW>`;
        
        headers.forEach(header => {
          let value = row[header] || '';
          
          // Handle date formatting
          if (header.includes('DATE') && value) {
            // Convert various date formats to ISO format
            const dateFormats = [
              /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/, // MM/DD/YYYY or M/D/YYYY
              /^(\d{2})-(\d{2})-(\d{4})$/, // MM-DD-YYYY
              /^(\d{4})-(\d{2})-(\d{2})$/ // YYYY-MM-DD
            ];
            
            for (const format of dateFormats) {
              const match = value.match(format);
              if (match) {
                if (format.source.startsWith('^(\\d{4})')) {
                  // Already in YYYY-MM-DD format
                  value = value;
                } else {
                  // Convert MM/DD/YYYY or MM-DD-YYYY to YYYY-MM-DD
                  const [, month, day, year] = match;
                  value = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
                }
                break;
              }
            }
          }
          
          // Handle special XML characters
          value = value.replace(/&/g, '&amp;')
                      .replace(/</g, '&lt;')
                      .replace(/>/g, '&gt;')
                      .replace(/"/g, '&quot;');
          
          const tagName = header.replace(/[^a-zA-Z0-9_]/g, '_').toUpperCase();
          xmlContent += `
      <${tagName}>${value}</${tagName}>`;
        });
        
        xmlContent += `
    </ROW>`;
      });

      xmlContent += `
  </CUSTOMER08>
</TICKETS>`;

      // Create a transformation record
      const transformation = await storage.createTransformation({
        name: `Transformation for ${csvFile.originalName}`,
        csvFileName: csvFile.originalName,
        xmlContent,
        status: "completed",
        config: transformationConfig || {}
      });

      res.json({
        transformation,
        xmlContent
      });
    } catch (error) {
      console.error('XML transformation error:', error);
      res.status(500).json({ message: "Failed to transform data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
