import { 
  users, transformations, databaseConfigs, csvFiles,
  type User, type InsertUser,
  type Transformation, type InsertTransformation,
  type DatabaseConfig, type InsertDatabaseConfig,
  type CsvFile, type InsertCsvFile
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Transformations
  getTransformations(): Promise<Transformation[]>;
  getTransformation(id: number): Promise<Transformation | undefined>;
  createTransformation(transformation: InsertTransformation): Promise<Transformation>;
  updateTransformation(id: number, transformation: Partial<InsertTransformation>): Promise<Transformation | undefined>;
  deleteTransformation(id: number): Promise<boolean>;

  // Database Configs
  getDatabaseConfigs(): Promise<DatabaseConfig[]>;
  getDatabaseConfig(id: number): Promise<DatabaseConfig | undefined>;
  createDatabaseConfig(config: InsertDatabaseConfig): Promise<DatabaseConfig>;
  updateDatabaseConfig(id: number, config: Partial<InsertDatabaseConfig>): Promise<DatabaseConfig | undefined>;
  deleteDatabaseConfig(id: number): Promise<boolean>;

  // CSV Files
  getCsvFiles(): Promise<CsvFile[]>;
  getCsvFile(id: number): Promise<CsvFile | undefined>;
  createCsvFile(file: InsertCsvFile): Promise<CsvFile>;
  deleteCsvFile(id: number): Promise<boolean>;

  // Dashboard metrics
  getDashboardMetrics(): Promise<{
    totalTransformations: number;
    activeConfigurations: number;
    successRate: string;
    databaseTargets: number;
  }>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private transformations: Map<number, Transformation>;
  private databaseConfigs: Map<number, DatabaseConfig>;
  private csvFiles: Map<number, CsvFile>;
  private currentUserId: number;
  private currentTransformationId: number;
  private currentDatabaseConfigId: number;
  private currentCsvFileId: number;

  constructor() {
    this.users = new Map();
    this.transformations = new Map();
    this.databaseConfigs = new Map();
    this.csvFiles = new Map();
    this.currentUserId = 1;
    this.currentTransformationId = 1;
    this.currentDatabaseConfigId = 1;
    this.currentCsvFileId = 1;

    // Initialize with some sample database configs
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Add sample database configurations
    this.createDatabaseConfig({
      name: "Production PostgreSQL",
      type: "postgresql",
      host: "localhost",
      port: 5432,
      database: "production_db",
      username: "admin",
      password: "password",
      isActive: true
    });

    this.createDatabaseConfig({
      name: "Analytics MongoDB",
      type: "mongodb",
      host: "localhost",
      port: 27017,
      database: "analytics_db",
      username: "analytics_user",
      password: "password",
      isActive: true
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Transformation methods
  async getTransformations(): Promise<Transformation[]> {
    return Array.from(this.transformations.values());
  }

  async getTransformation(id: number): Promise<Transformation | undefined> {
    return this.transformations.get(id);
  }

  async createTransformation(insertTransformation: InsertTransformation): Promise<Transformation> {
    const id = this.currentTransformationId++;
    const transformation: Transformation = {
      ...insertTransformation,
      id,
      createdAt: new Date()
    };
    this.transformations.set(id, transformation);
    return transformation;
  }

  async updateTransformation(id: number, update: Partial<InsertTransformation>): Promise<Transformation | undefined> {
    const existing = this.transformations.get(id);
    if (!existing) return undefined;

    const updated: Transformation = { ...existing, ...update };
    this.transformations.set(id, updated);
    return updated;
  }

  async deleteTransformation(id: number): Promise<boolean> {
    return this.transformations.delete(id);
  }

  // Database Config methods
  async getDatabaseConfigs(): Promise<DatabaseConfig[]> {
    return Array.from(this.databaseConfigs.values());
  }

  async getDatabaseConfig(id: number): Promise<DatabaseConfig | undefined> {
    return this.databaseConfigs.get(id);
  }

  async createDatabaseConfig(insertConfig: InsertDatabaseConfig): Promise<DatabaseConfig> {
    const id = this.currentDatabaseConfigId++;
    const config: DatabaseConfig = {
      ...insertConfig,
      id,
      createdAt: new Date()
    };
    this.databaseConfigs.set(id, config);
    return config;
  }

  async updateDatabaseConfig(id: number, update: Partial<InsertDatabaseConfig>): Promise<DatabaseConfig | undefined> {
    const existing = this.databaseConfigs.get(id);
    if (!existing) return undefined;

    const updated: DatabaseConfig = { ...existing, ...update };
    this.databaseConfigs.set(id, updated);
    return updated;
  }

  async deleteDatabaseConfig(id: number): Promise<boolean> {
    return this.databaseConfigs.delete(id);
  }

  // CSV File methods
  async getCsvFiles(): Promise<CsvFile[]> {
    return Array.from(this.csvFiles.values());
  }

  async getCsvFile(id: number): Promise<CsvFile | undefined> {
    return this.csvFiles.get(id);
  }

  async createCsvFile(insertFile: InsertCsvFile): Promise<CsvFile> {
    const id = this.currentCsvFileId++;
    const file: CsvFile = {
      ...insertFile,
      id,
      uploadedAt: new Date()
    };
    this.csvFiles.set(id, file);
    return file;
  }

  async deleteCsvFile(id: number): Promise<boolean> {
    return this.csvFiles.delete(id);
  }

  // Dashboard metrics
  async getDashboardMetrics() {
    const totalTransformations = this.transformations.size;
    const activeConfigurations = Array.from(this.databaseConfigs.values()).filter(config => config.isActive).length;
    const successfulTransformations = Array.from(this.transformations.values()).filter(t => t.status === 'completed').length;
    const successRate = totalTransformations > 0 ? Math.round((successfulTransformations / totalTransformations) * 100) : 0;
    const databaseTargets = this.databaseConfigs.size;

    return {
      totalTransformations,
      activeConfigurations,
      successRate: `${successRate}%`,
      databaseTargets
    };
  }
}

export const storage = new MemStorage();
