import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertWorkflowSchema, workflowDataSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all workflows
  app.get("/api/workflows", async (req, res) => {
    try {
      const workflows = await storage.getWorkflows();
      res.json(workflows);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch workflows" });
    }
  });

  // Get workflow by ID
  app.get("/api/workflows/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid workflow ID" });
      }

      const workflow = await storage.getWorkflow(id);
      if (!workflow) {
        return res.status(404).json({ message: "Workflow not found" });
      }

      res.json(workflow);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch workflow" });
    }
  });

  // Create new workflow
  app.post("/api/workflows", async (req, res) => {
    try {
      const validatedData = insertWorkflowSchema.parse(req.body);
      const workflow = await storage.createWorkflow(validatedData);
      res.status(201).json(workflow);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid workflow data",
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create workflow" });
    }
  });

  // Update workflow
  app.put("/api/workflows/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid workflow ID" });
      }

      const validatedData = insertWorkflowSchema.partial().parse(req.body);
      const workflow = await storage.updateWorkflow(id, validatedData);
      
      if (!workflow) {
        return res.status(404).json({ message: "Workflow not found" });
      }

      res.json(workflow);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid workflow data",
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to update workflow" });
    }
  });

  // Delete workflow
  app.delete("/api/workflows/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid workflow ID" });
      }

      const success = await storage.deleteWorkflow(id);
      if (!success) {
        return res.status(404).json({ message: "Workflow not found" });
      }

      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete workflow" });
    }
  });

  // Validate workflow
  app.post("/api/workflows/validate", async (req, res) => {
    try {
      const workflowData = workflowDataSchema.parse(req.body);
      
      // Enhanced validation logic with detailed error messages
      const errors: string[] = [];
      const warnings: string[] = [];
      
      if (workflowData.nodes.length === 0) {
        errors.push("Workflow is empty. Please add at least one component to start building your workflow.");
        return res.json({ isValid: false, errors, warnings });
      }

      // Check for isolated nodes (nodes without connections)
      const connectedNodes = new Set();
      workflowData.edges.forEach(edge => {
        connectedNodes.add(edge.source);
        connectedNodes.add(edge.target);
      });
      
      const isolatedNodes = workflowData.nodes.filter(node => 
        !connectedNodes.has(node.id) && workflowData.nodes.length > 1
      );
      
      if (isolatedNodes.length > 0) {
        const nodeDetails = isolatedNodes.map(n => `"${n.data.label}" (${n.type})`).join(', ');
        errors.push(`Found ${isolatedNodes.length} isolated component(s): ${nodeDetails}`);
        errors.push("💡 Solution: Connect these components using the connection handles (small dots) on each component. Drag from one component's output to another component's input.");
      }

      // Check for input nodes
      const inputNodeTypes = ['database', 'api', 'file'];
      const inputNodes = workflowData.nodes.filter(node => inputNodeTypes.includes(node.type));
      const hasInputNodes = inputNodes.length > 0;

      if (!hasInputNodes) {
        errors.push("Missing data source: Your workflow needs at least one input component.");
        errors.push("💡 Available input components: Database (SQL/NoSQL), API (REST/GraphQL), or File Input (CSV/JSON/Excel)");
        errors.push("📍 Add one from the 'Data Sources' section in the left panel.");
      }

      // Check for output nodes
      const outputNodeTypes = ['export', 'email'];
      const outputNodes = workflowData.nodes.filter(node => outputNodeTypes.includes(node.type));
      const hasOutputNodes = outputNodes.length > 0;

      if (!hasOutputNodes) {
        errors.push("Missing output destination: Your workflow needs at least one output component.");
        errors.push("💡 Available output components: Export (save to file/database) or Email (send notifications)");
        errors.push("📍 Add one from the 'Outputs' section in the left panel.");
      }

      // Check for processing flow
      if (hasInputNodes && hasOutputNodes && workflowData.edges.length === 0) {
        errors.push("Components are not connected: You have input and output components but they're not linked together.");
        errors.push("💡 Create connections by dragging from the small blue dots on the right side of components to the dots on the left side of other components.");
      }

      // Check for incomplete connections
      const sourceNodes = new Set(workflowData.edges.map(e => e.source));
      const targetNodes = new Set(workflowData.edges.map(e => e.target));
      
      const disconnectedInputs = inputNodes.filter(node => !sourceNodes.has(node.id));
      const disconnectedOutputs = outputNodes.filter(node => !targetNodes.has(node.id));

      if (disconnectedInputs.length > 0 && workflowData.edges.length > 0) {
        warnings.push(`Input component(s) not connected: ${disconnectedInputs.map(n => n.data.label).join(', ')}`);
      }

      if (disconnectedOutputs.length > 0 && workflowData.edges.length > 0) {
        warnings.push(`Output component(s) not connected: ${disconnectedOutputs.map(n => n.data.label).join(', ')}`);
      }

      // Check for cycles (circular dependencies)
      const hasCycles = detectCycles(workflowData.nodes, workflowData.edges);
      if (hasCycles) {
        errors.push("Circular dependency detected: Your workflow has components that depend on each other in a loop.");
        errors.push("💡 Remove connections that create circular references. Data should flow in one direction from inputs to outputs.");
      }

      res.json({
        isValid: errors.length === 0,
        errors,
        warnings
      });
    } catch (error) {
      res.status(400).json({ 
        message: "Invalid workflow data format",
        isValid: false,
        errors: ["The workflow data structure is invalid. Please try recreating your workflow."]
      });
    }
  });

  // Helper function to detect cycles
  function detectCycles(nodes: any[], edges: any[]): boolean {
    const graph = new Map<string, string[]>();
    
    // Build adjacency list
    nodes.forEach(node => {
      graph.set(node.id, []);
    });
    
    edges.forEach(edge => {
      const neighbors = graph.get(edge.source) || [];
      neighbors.push(edge.target);
      graph.set(edge.source, neighbors);
    });

    // DFS cycle detection
    const visited = new Set<string>();
    const inStack = new Set<string>();

    function dfs(nodeId: string): boolean {
      if (inStack.has(nodeId)) return true;
      if (visited.has(nodeId)) return false;

      visited.add(nodeId);
      inStack.add(nodeId);

      const neighbors = graph.get(nodeId) || [];
      for (const neighbor of neighbors) {
        if (dfs(neighbor)) return true;
      }

      inStack.delete(nodeId);
      return false;
    }

    const nodeIds = Array.from(graph.keys());
    for (const nodeId of nodeIds) {
      if (!visited.has(nodeId)) {
        if (dfs(nodeId)) return true;
      }
    }

    return false;
  }

  // Generate Python code
  app.post("/api/workflows/generate-python", async (req, res) => {
    try {
      const workflowData = workflowDataSchema.parse(req.body);
      
      let pythonCode = `#!/usr/bin/env python3
"""
Generated Python code for workflow execution
This code is compatible with Apache Airflow
"""

from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
import pandas as pd
import json

# Default DAG arguments
default_args = {
    'owner': 'workflow-designer',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

# Create DAG
dag = DAG(
    'generated_workflow',
    default_args=default_args,
    description='Auto-generated workflow',
    schedule_interval=timedelta(days=1),
    catchup=False,
)

`;

      // Generate task functions for each node
      workflowData.nodes.forEach(node => {
        pythonCode += `
def ${node.id}_task(**context):
    """${node.data.label} task"""
    print(f"Executing ${node.data.label}")
    
    # TODO: Implement ${node.type} logic here
    # Node configuration: ${JSON.stringify(node.data.config || {})}
    
    # Placeholder implementation
    data = {"status": "completed", "node_id": "${node.id}"}
    return data

`;
      });

      // Generate task definitions
      pythonCode += "\n# Task definitions\n";
      workflowData.nodes.forEach(node => {
        pythonCode += `
${node.id} = PythonOperator(
    task_id='${node.id}',
    python_callable=${node.id}_task,
    dag=dag,
)
`;
      });

      // Generate task dependencies
      if (workflowData.edges.length > 0) {
        pythonCode += "\n# Task dependencies\n";
        workflowData.edges.forEach(edge => {
          pythonCode += `${edge.source} >> ${edge.target}\n`;
        });
      }

      res.json({ code: pythonCode });
    } catch (error) {
      res.status(400).json({ 
        message: "Failed to generate Python code",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
