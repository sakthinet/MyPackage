# Windows Setup Guide - Visual Workflow Designer

## Simple 3-Step Setup

1. **Download and extract the project files**
2. **Double-click `start.bat`** 
3. **Open browser to `http://localhost:5000`**

That's it! The batch file will automatically:
- Check if Node.js is installed
- Install all dependencies 
- Start the server
- Show you the URL to open

## If start.bat doesn't work

### Option 1: Manual Command Line
1. Open Command Prompt in the project folder
2. Run these commands one by one:
   ```cmd
   npm install
   set NODE_ENV=development
   npx tsx server/index.ts
   ```

### Option 2: Fix Port Issues
- Close Skype (uses port 5000)
- Disable "Fast startup" in Windows Power Options
- Run Command Prompt as Administrator

### Option 3: Alternative Port
If port 5000 is blocked, you can use a different port by editing `server/index.ts` and changing line 62 from `const port = 5000;` to `const port = 3000;`

## Common Windows Issues

**"Node.js not found"**
- Download and install Node.js from https://nodejs.org/
- Choose the LTS version (recommended)
- Restart Command Prompt after installation

**"Permission denied" or "Access denied"**
- Run Command Prompt as Administrator
- Right-click Command Prompt → "Run as administrator"

**Port 5000 already in use**
- Close Skype or other programs using port 5000
- Or edit the port number in server/index.ts

**Firewall blocking connection**
- Allow Node.js through Windows Firewall
- Temporarily disable antivirus to test

## What You Get

Once running, the workflow designer includes:
- Drag-and-drop visual interface
- Multiple component types (Database, API, File, Processing, Export)
- Real-time validation with helpful error messages  
- JSON export and Python/Airflow code generation
- Process ID assignment based on workflow execution order

The interface is optimized for Windows and will automatically use `localhost` instead of `0.0.0.0` for better Windows compatibility.