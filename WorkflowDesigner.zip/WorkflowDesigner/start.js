#!/usr/bin/env node

// Cross-platform startup script for the workflow designer
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

// Check if we're in development or production mode
const isDev = process.argv.includes('--dev') || process.argv.includes('-d');
const isHelp = process.argv.includes('--help') || process.argv.includes('-h');

if (isHelp) {
  console.log(`
Visual Workflow Designer - Startup Script

Usage:
  node start.js [options]

Options:
  --dev, -d     Start in development mode
  --help, -h    Show this help message

Examples:
  node start.js --dev    # Development mode
  node start.js          # Production mode
`);
  process.exit(0);
}

// Set environment variables cross-platform
process.env.NODE_ENV = isDev ? 'development' : 'production';

// Check if dist folder exists for production
if (!isDev && !fs.existsSync('dist')) {
  console.log('Building application for production...');
  
  // Run build first
  const buildProcess = spawn('npm', ['run', 'build'], {
    stdio: 'inherit',
    shell: true
  });
  
  buildProcess.on('close', (code) => {
    if (code === 0) {
      startServer();
    } else {
      console.error('Build failed. Please check the errors above.');
      process.exit(1);
    }
  });
} else {
  startServer();
}

function startServer() {
  console.log(`Starting server in ${process.env.NODE_ENV} mode...`);
  
  let command, args;
  
  if (isDev) {
    // Development mode using tsx
    command = 'npx';
    args = ['tsx', 'server/index.ts'];
  } else {
    // Production mode using built files
    command = 'node';
    args = ['dist/index.js'];
  }
  
  const serverProcess = spawn(command, args, {
    stdio: 'inherit',
    shell: true,
    env: { ...process.env }
  });
  
  serverProcess.on('close', (code) => {
    console.log(`Server process exited with code ${code}`);
  });
  
  serverProcess.on('error', (err) => {
    console.error('Failed to start server:', err.message);
    console.log('\nTroubleshooting:');
    console.log('1. Make sure Node.js is installed (version 18+)');
    console.log('2. Run "npm install" to install dependencies');
    console.log('3. Check if port 5000 is available');
  });
  
  // Handle graceful shutdown
  process.on('SIGINT', () => {
    console.log('\nShutting down server...');
    serverProcess.kill('SIGINT');
  });
  
  process.on('SIGTERM', () => {
    console.log('\nShutting down server...');
    serverProcess.kill('SIGTERM');
  });
}