# Setup Instructions for Visual Workflow Designer

## Quick Start (Recommended)

### Windows Users
1. Double-click `start.bat` file in the project folder
2. The script will automatically install dependencies and start the server
3. Open browser to `http://localhost:5000`

### macOS/Linux Users
1. Open terminal in the project folder
2. Run: `./start.sh`
3. Open browser to `http://localhost:5000`

### Cross-Platform (Node.js)
1. Open terminal/command prompt in project folder
2. Run: `node start.js --dev` (development) or `node start.js` (production)
3. Open browser to `http://localhost:5000`

## Manual Installation

If the automatic scripts don't work:

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Development mode:**
   ```bash
   # Windows
   set NODE_ENV=development && npx tsx server/index.ts
   
   # macOS/Linux
   NODE_ENV=development npx tsx server/index.ts
   ```

3. **Production mode:**
   ```bash
   npm run build
   
   # Windows
   set NODE_ENV=production && node dist/index.js
   
   # macOS/Linux
   NODE_ENV=production node dist/index.js
   ```

## Troubleshooting

### Error: 'NODE_ENV' is not recognized
- Use the provided startup scripts (start.bat, start.sh, or start.js)
- These handle cross-platform environment variable setting

### Port 5000 already in use
- Close other applications using port 5000
- Or modify the port in `server/index.ts`

### Dependencies not found
- Run `npm install` in the project directory
- Ensure Node.js 18+ is installed

### Build errors
- Delete `node_modules` and `dist` folders
- Run `npm install` again
- Try development mode first: `node start.js --dev`

## Features Available

Once running, you can:
- Drag components from the left sidebar to create workflows
- Connect components using blue connection handles
- Configure component properties via the three-dot menu
- Validate workflows with detailed error messages
- Export workflows as JSON or Python/Airflow code

The application includes comprehensive validation that guides you through building proper workflows with clear error messages and solutions.