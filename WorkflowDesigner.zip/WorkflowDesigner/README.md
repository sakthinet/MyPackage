# Visual Workflow Designer

A drag-and-drop workflow designer for creating data processing pipelines with JSON and Python export capabilities.

## Features

- **Visual Interface**: Drag-and-drop components to build workflows
- **Multiple Data Sources**: Database, API, and File inputs
- **Processing Components**: Filter, Transform, Aggregate, and Join operations
- **Output Options**: Export to files/databases or send email notifications
- **Validation**: Real-time workflow validation with detailed error messages
- **Code Generation**: Export workflows as JSON or generate Python code for Apache Airflow
- **Process Management**: Sequential process IDs based on execution order

## Quick Start

### Prerequisites

- Node.js 18+ installed
- npm or yarn package manager

### Installation

1. **Download and extract the project**
2. **Open terminal/command prompt in the project directory**
3. **Install dependencies:**
   ```bash
   npm install
   ```

### Development

Start the development server:
```bash
npm run dev
```

The application will be available at `http://localhost:5000`

### Production Build

Build the application:
```bash
npm run build
```

Start the production server:
```bash
npm start
```

## Cross-Platform Compatibility

The project uses `cross-env` to ensure compatibility across Windows, macOS, and Linux systems.

### Windows Users

If you encounter `NODE_ENV is not recognized` error:

1. Make sure you've run `npm install` first
2. Use the npm scripts provided instead of direct commands:
   - Development: `npm run dev`
   - Production: `npm run build && npm start`

### Alternative Manual Setup (if npm scripts fail)

**For Windows:**
```cmd
set NODE_ENV=development
node server/index.ts
```

**For macOS/Linux:**
```bash
export NODE_ENV=development
node server/index.ts
```

## Usage Guide

### Creating a Workflow

1. **Add Components**: Drag components from the left sidebar to the canvas
   - **Data Sources**: Database, API, File Input
   - **Processing**: Filter, Transform, Aggregate, Join
   - **Outputs**: Export, Email

2. **Connect Components**: 
   - Drag from blue dots on the right side of components
   - Connect to blue dots on the left side of other components
   - Data flows from left to right

3. **Configure Properties**:
   - Click the three-dot menu on any component
   - Select "Properties" to configure component settings
   - Each component type has specific configuration options

4. **Validate Workflow**:
   - Click "Validate" in the toolbar
   - Review any error messages and follow the provided solutions

5. **Export Options**:
   - **JSON**: Download workflow configuration
   - **Python**: Generate Apache Airflow DAG code

### Process IDs

Components are automatically assigned Process IDs based on their execution order in the workflow. The numbering follows the data flow from inputs through processing to outputs.

## Project Structure

```
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/     # React components
│   │   ├── pages/         # Application pages
│   │   └── lib/           # Utilities and types
├── server/                # Backend Express server
│   ├── index.ts          # Server entry point
│   ├── routes.ts         # API routes
│   └── storage.ts        # Data storage interface
├── shared/               # Shared types and schemas
└── README.md            # This file
```

## API Endpoints

- `GET /api/workflows` - List all workflows
- `POST /api/workflows` - Create new workflow
- `PUT /api/workflows/:id` - Update workflow
- `DELETE /api/workflows/:id` - Delete workflow
- `POST /api/workflows/validate` - Validate workflow structure
- `POST /api/workflows/generate-python` - Generate Python/Airflow code

## Troubleshooting

### Common Issues

1. **Dependencies not found**: Run `npm install`
2. **Port already in use**: The app uses port 5000 by default
3. **Build failures**: Ensure Node.js 18+ is installed
4. **React Flow issues**: Clear browser cache and restart

### Support

If you encounter issues:
1. Check that all dependencies are installed
2. Verify Node.js version (18+)
3. Clear browser cache
4. Restart the development server

## Technology Stack

- **Frontend**: React, TypeScript, Vite, TailwindCSS
- **Backend**: Node.js, Express, TypeScript
- **UI Components**: Radix UI, Lucide React
- **Workflow Engine**: React Flow
- **Validation**: Zod
- **Build Tools**: Vite, ESBuild