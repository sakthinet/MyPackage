#!/bin/bash

# Linux/macOS shell script for starting the workflow designer

echo "Visual Workflow Designer - Unix Startup Script"

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "Error: Node.js is not installed or not in PATH"
    echo "Please install Node.js from https://nodejs.org/"
    exit 1
fi

# Check if package.json exists
if [ ! -f "package.json" ]; then
    echo "Error: package.json not found"
    echo "Please run this script from the project root directory"
    exit 1
fi

# Check if node_modules exists, if not install dependencies
if [ ! -d "node_modules" ]; then
    echo "Installing dependencies..."
    npm install
    if [ $? -ne 0 ]; then
        echo "Error: Failed to install dependencies"
        exit 1
    fi
fi

# Parse command line arguments
DEV_MODE=0
case "$1" in
    --dev|-d)
        DEV_MODE=1
        ;;
    --help|-h)
        echo ""
        echo "Usage: ./start.sh [options]"
        echo ""
        echo "Options:"
        echo "  --dev, -d     Start in development mode"
        echo "  --help, -h    Show this help message"
        echo ""
        echo "Examples:"
        echo "  ./start.sh --dev    # Development mode"
        echo "  ./start.sh          # Production mode"
        echo ""
        exit 0
        ;;
esac

if [ $DEV_MODE -eq 1 ]; then
    echo "Starting in development mode..."
    export NODE_ENV=development
    npx tsx server/index.ts
else
    echo "Starting in production mode..."
    export NODE_ENV=production
    
    # Build if dist doesn't exist
    if [ ! -d "dist" ]; then
        echo "Building application..."
        npm run build
        if [ $? -ne 0 ]; then
            echo "Error: Build failed"
            exit 1
        fi
    fi
    
    node dist/index.js
fi

if [ $? -ne 0 ]; then
    echo ""
    echo "Server failed to start. Troubleshooting:"
    echo "1. Make sure port 5000 is available"
    echo "2. Check if all dependencies are installed: npm install"
    echo "3. Try development mode: ./start.sh --dev"
fi