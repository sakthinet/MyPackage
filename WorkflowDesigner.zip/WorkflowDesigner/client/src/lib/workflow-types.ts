export interface WorkflowNode {
  id: string;
  type: string;
  position: {
    x: number;
    y: number;
  };
  data: {
    label: string;
    config?: Record<string, any>;
  };
}

export interface WorkflowConnection {
  id: string;
  source: string;
  target: string;
  sourceHandle?: string;
  targetHandle?: string;
}

export interface WorkflowData {
  nodes: WorkflowNode[];
  edges: WorkflowConnection[];
}

export type NodeType = 
  | 'database'
  | 'api'
  | 'file'
  | 'filter'
  | 'transform'
  | 'aggregate'
  | 'join'
  | 'export'
  | 'email';

export interface NodeConfig {
  [key: string]: any;
}

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

export interface PythonGenerationResult {
  code: string;
}
