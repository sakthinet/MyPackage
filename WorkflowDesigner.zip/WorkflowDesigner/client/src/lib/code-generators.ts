import { WorkflowNode, WorkflowConnection } from "./workflow-types";

export function generatePythonCode(nodes: WorkflowNode[], edges: WorkflowConnection[]): string {
  const header = `#!/usr/bin/env python3
"""
Generated Python code for workflow execution
This code is compatible with Apache Airflow
"""

from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
import pandas as pd
import json

# Default DAG arguments
default_args = {
    'owner': 'workflow-designer',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

# Create DAG
dag = DAG(
    'generated_workflow',
    default_args=default_args,
    description='Auto-generated workflow',
    schedule_interval=timedelta(days=1),
    catchup=False,
)

`;

  // Generate task functions
  let taskFunctions = "";
  nodes.forEach(node => {
    taskFunctions += generateTaskFunction(node);
  });

  // Generate task definitions
  let taskDefinitions = "\n# Task definitions\n";
  nodes.forEach(node => {
    taskDefinitions += `
${node.id} = PythonOperator(
    task_id='${node.id}',
    python_callable=${node.id}_task,
    dag=dag,
)
`;
  });

  // Generate dependencies
  let dependencies = "";
  if (edges.length > 0) {
    dependencies = "\n# Task dependencies\n";
    edges.forEach(edge => {
      dependencies += `${edge.source} >> ${edge.target}\n`;
    });
  }

  return header + taskFunctions + taskDefinitions + dependencies;
}

function generateTaskFunction(node: WorkflowNode): string {
  const config = node.data.config || {};
  
  switch (node.type) {
    case 'database':
      return `
def ${node.id}_task(**context):
    """${node.data.label} task - Database source"""
    import pandas as pd
    from sqlalchemy import create_engine
    
    # Configuration
    connection_string = "${config.connectionString || 'postgresql://user:pass@host:port/db'}"
    query = """${config.query || 'SELECT * FROM table'}"""
    
    try:
        engine = create_engine(connection_string)
        df = pd.read_sql(query, engine)
        
        print(f"Retrieved {len(df)} rows from database")
        
        # Store result for downstream tasks
        context['task_instance'].xcom_push(key='data', value=df.to_json())
        
        return {"status": "success", "rows": len(df)}
    except Exception as e:
        print(f"Database task failed: {str(e)}")
        raise

`;

    case 'api':
      return `
def ${node.id}_task(**context):
    """${node.data.label} task - API source"""
    import requests
    import pandas as pd
    
    # Configuration
    endpoint = "${config.endpoint || 'https://api.example.com/data'}"
    method = "${config.method || 'GET'}"
    headers = ${config.headers || '{}'}
    
    try:
        response = requests.request(method, endpoint, headers=headers)
        response.raise_for_status()
        
        data = response.json()
        df = pd.json_normalize(data)
        
        print(f"Retrieved {len(df)} rows from API")
        
        # Store result for downstream tasks
        context['task_instance'].xcom_push(key='data', value=df.to_json())
        
        return {"status": "success", "rows": len(df)}
    except Exception as e:
        print(f"API task failed: {str(e)}")
        raise

`;

    case 'filter':
      return `
def ${node.id}_task(**context):
    """${node.data.label} task - Data filtering"""
    import pandas as pd
    
    # Get data from upstream task
    upstream_data = context['task_instance'].xcom_pull(key='data')
    df = pd.read_json(upstream_data)
    
    # Configuration
    condition = "${config.condition || 'True'}"
    
    try:
        # Apply filter
        filtered_df = df.query(condition)
        
        print(f"Filtered from {len(df)} to {len(filtered_df)} rows")
        
        # Store result for downstream tasks
        context['task_instance'].xcom_push(key='data', value=filtered_df.to_json())
        
        return {"status": "success", "rows": len(filtered_df)}
    except Exception as e:
        print(f"Filter task failed: {str(e)}")
        raise

`;

    default:
      return `
def ${node.id}_task(**context):
    """${node.data.label} task"""
    print(f"Executing {node.data.label}")
    
    # TODO: Implement ${node.type} logic here
    # Node configuration: ${JSON.stringify(config)}
    
    # Placeholder implementation
    data = {"status": "completed", "node_id": "${node.id}"}
    return data

`;
  }
}

export function validateWorkflow(nodes: WorkflowNode[], edges: WorkflowConnection[]): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  if (nodes.length === 0) {
    return { isValid: false, errors: ["Workflow cannot be empty"] };
  }

  // Check for isolated nodes
  const connectedNodes = new Set<string>();
  edges.forEach(edge => {
    connectedNodes.add(edge.source);
    connectedNodes.add(edge.target);
  });
  
  const isolatedNodes = nodes.filter(node => !connectedNodes.has(node.id) && nodes.length > 1);
  if (isolatedNodes.length > 0) {
    errors.push(`Isolated nodes found: ${isolatedNodes.map(n => n.data.label).join(', ')}`);
  }

  // Check for input nodes
  const inputNodeTypes = ['database', 'api', 'file'];
  const hasInputNodes = nodes.some(node => inputNodeTypes.includes(node.type));
  if (!hasInputNodes) {
    errors.push("Workflow must have at least one input node (Database, API, or File)");
  }

  // Check for output nodes
  const outputNodeTypes = ['export', 'email'];
  const hasOutputNodes = nodes.some(node => outputNodeTypes.includes(node.type));
  if (!hasOutputNodes) {
    errors.push("Workflow must have at least one output node (Export or Email)");
  }

  // Check for cycles (basic detection)
  const hasCycles = detectCycles(nodes, edges);
  if (hasCycles) {
    errors.push("Workflow contains circular dependencies");
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

function detectCycles(nodes: WorkflowNode[], edges: WorkflowConnection[]): boolean {
  const graph = new Map<string, string[]>();
  
  // Build adjacency list
  nodes.forEach(node => {
    graph.set(node.id, []);
  });
  
  edges.forEach(edge => {
    const neighbors = graph.get(edge.source) || [];
    neighbors.push(edge.target);
    graph.set(edge.source, neighbors);
  });

  // DFS cycle detection
  const visited = new Set<string>();
  const inStack = new Set<string>();

  function dfs(nodeId: string): boolean {
    if (inStack.has(nodeId)) return true;
    if (visited.has(nodeId)) return false;

    visited.add(nodeId);
    inStack.add(nodeId);

    const neighbors = graph.get(nodeId) || [];
    for (const neighbor of neighbors) {
      if (dfs(neighbor)) return true;
    }

    inStack.delete(nodeId);
    return false;
  }

  for (const nodeId of graph.keys()) {
    if (!visited.has(nodeId)) {
      if (dfs(nodeId)) return true;
    }
  }

  return false;
}
