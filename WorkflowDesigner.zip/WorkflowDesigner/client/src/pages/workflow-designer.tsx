import { useState, useCallback } from "react";
import { Helmet } from "react-helmet";
import WorkflowCanvas from "@/components/workflow-canvas";
import ComponentLibrary from "@/components/component-library";
import PropertiesPanel from "@/components/properties-panel";
import WorkflowToolbar from "@/components/workflow-toolbar";
import { WorkflowNode, WorkflowConnection } from "@/lib/workflow-types";

export default function WorkflowDesigner() {
  const [nodes, setNodes] = useState<WorkflowNode[]>([]);
  const [edges, setEdges] = useState<WorkflowConnection[]>([]);
  const [selectedNode, setSelectedNode] = useState<WorkflowNode | null>(null);
  const [isLeftSidebarCollapsed, setIsLeftSidebarCollapsed] = useState(false);
  const [isRightSidebarCollapsed, setIsRightSidebarCollapsed] = useState(false);
  const [workflowName, setWorkflowName] = useState("Untitled Workflow");

  const onNodesChange = useCallback((changes: any) => {
    setNodes((nds) => {
      // Handle node changes from React Flow
      const updatedNodes = nds.map(node => {
        const change = changes.find((c: any) => c.id === node.id);
        if (change) {
          if (change.type === 'position' && change.position) {
            return { ...node, position: change.position };
          }
          if (change.type === 'select') {
            if (change.selected && !selectedNode) {
              setSelectedNode(node);
            }
            return node;
          }
        }
        return node;
      });
      return updatedNodes;
    });
  }, [selectedNode]);

  const onEdgesChange = useCallback((changes: any) => {
    setEdges((eds) => {
      // Handle edge changes from React Flow
      return eds.filter(edge => {
        const change = changes.find((c: any) => c.id === edge.id);
        return !change || change.type !== 'remove';
      });
    });
  }, []);

  const onConnect = useCallback((connection: any) => {
    const newEdge: WorkflowConnection = {
      id: `${connection.source}-${connection.target}`,
      source: connection.source,
      target: connection.target,
      sourceHandle: connection.sourceHandle,
      targetHandle: connection.targetHandle,
    };
    setEdges((eds) => [...eds, newEdge]);
  }, []);

  const addNode = useCallback((nodeType: string, position: { x: number; y: number }) => {
    const nodeId = `${nodeType}-${Date.now()}`;
    const newNode: WorkflowNode = {
      id: nodeId,
      type: nodeType,
      position,
      data: {
        label: getNodeLabel(nodeType),
        config: {},
      },
    };
    setNodes((nds) => [...nds, newNode]);
  }, []);

  const updateNodeConfig = useCallback((nodeId: string, config: any) => {
    setNodes((nds) =>
      nds.map((node) =>
        node.id === nodeId
          ? { ...node, data: { ...node.data, config: { ...node.data.config, ...config } } }
          : node
      )
    );
  }, []);

  const deleteSelectedNode = useCallback(() => {
    if (selectedNode) {
      setNodes((nds) => nds.filter((node) => node.id !== selectedNode.id));
      setEdges((eds) => eds.filter((edge) => 
        edge.source !== selectedNode.id && edge.target !== selectedNode.id
      ));
      setSelectedNode(null);
    }
  }, [selectedNode]);

  const deleteNode = useCallback((nodeId: string) => {
    setNodes((nds) => nds.filter((node) => node.id !== nodeId));
    setEdges((eds) => eds.filter((edge) => 
      edge.source !== nodeId && edge.target !== nodeId
    ));
    if (selectedNode && selectedNode.id === nodeId) {
      setSelectedNode(null);
    }
  }, [selectedNode]);

  return (
    <>
      <Helmet>
        <title>Workflow Designer - Create Data Processing Pipelines</title>
        <meta 
          name="description" 
          content="Design and create data processing workflows with drag-and-drop interface. Export to JSON or generate Python code for Apache Airflow." 
        />
      </Helmet>
      
      <div className="flex h-screen bg-[hsl(240,10%,7.1%)] text-white font-inter overflow-hidden">
        {/* Left Sidebar - Component Library */}
        <ComponentLibrary
          isCollapsed={isLeftSidebarCollapsed}
          onToggle={() => setIsLeftSidebarCollapsed(!isLeftSidebarCollapsed)}
          onAddNode={addNode}
        />

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col">
          {/* Top Toolbar */}
          <WorkflowToolbar
            workflowName={workflowName}
            onWorkflowNameChange={setWorkflowName}
            nodes={nodes}
            edges={edges}
            onDeleteSelected={deleteSelectedNode}
            hasSelectedNode={!!selectedNode}
          />

          {/* Canvas Area */}
          <div className="flex-1">
            <WorkflowCanvas
              nodes={nodes}
              edges={edges}
              selectedNode={selectedNode}
              onNodesChange={onNodesChange}
              onEdgesChange={onEdgesChange}
              onConnect={onConnect}
              onNodeSelect={setSelectedNode}
              onAddNode={addNode}
              onDeleteNode={deleteNode}
            />
          </div>
        </div>

        {/* Right Sidebar - Properties Panel */}
        <PropertiesPanel
          isCollapsed={isRightSidebarCollapsed}
          onToggle={() => setIsRightSidebarCollapsed(!isRightSidebarCollapsed)}
          selectedNode={selectedNode}
          onUpdateNode={updateNodeConfig}
          nodes={nodes}
        />
      </div>
    </>
  );
}

function getNodeLabel(nodeType: string): string {
  const labels: { [key: string]: string } = {
    database: "Database",
    api: "API Source",
    file: "File Input",
    filter: "Filter",
    transform: "Transform",
    aggregate: "Aggregate",
    join: "Join",
    export: "Export",
    email: "Email",
  };
  return labels[nodeType] || "Unknown";
}
