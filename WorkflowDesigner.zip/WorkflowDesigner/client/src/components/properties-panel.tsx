import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight, MousePointer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { WorkflowNode } from "@/lib/workflow-types";

interface PropertiesPanelProps {
  isCollapsed: boolean;
  onToggle: () => void;
  selectedNode: WorkflowNode | null;
  onUpdateNode: (nodeId: string, config: any) => void;
  nodes: WorkflowNode[];
}

export default function PropertiesPanel({ 
  isCollapsed, 
  onToggle, 
  selectedNode, 
  onUpdateNode,
  nodes 
}: PropertiesPanelProps) {
  const [localConfig, setLocalConfig] = useState<any>({});

  useEffect(() => {
    if (selectedNode) {
      setLocalConfig(selectedNode.data.config || {});
    } else {
      setLocalConfig({});
    }
  }, [selectedNode]);

  const updateConfig = (key: string, value: any) => {
    const newConfig = { ...localConfig, [key]: value };
    setLocalConfig(newConfig);
    if (selectedNode) {
      onUpdateNode(selectedNode.id, { [key]: value });
    }
  };

  const renderNodeSpecificConfig = () => {
    if (!selectedNode) return null;

    switch (selectedNode.type) {
      case "database":
        return (
          <>
            <div className="space-y-4">
              <div>
                <Label className="text-white">Connection String</Label>
                <Input
                  className="mt-2 bg-[hsl(240,7%,17.6%)] border-[hsl(240,3.7%,20%)] text-white"
                  placeholder="postgresql://user:pass@host:port/db"
                  value={localConfig.connectionString || ""}
                  onChange={(e) => updateConfig("connectionString", e.target.value)}
                />
              </div>
              <div>
                <Label className="text-white">Query</Label>
                <Textarea
                  className="mt-2 bg-[hsl(240,7%,17.6%)] border-[hsl(240,3.7%,20%)] text-white font-mono text-sm h-32 resize-none"
                  placeholder="SELECT * FROM users;"
                  value={localConfig.query || ""}
                  onChange={(e) => updateConfig("query", e.target.value)}
                />
              </div>
              <div>
                <Label className="text-white">Timeout (seconds)</Label>
                <Input
                  type="number"
                  className="mt-2 bg-[hsl(240,7%,17.6%)] border-[hsl(240,3.7%,20%)] text-white"
                  value={localConfig.timeout || 30}
                  onChange={(e) => updateConfig("timeout", parseInt(e.target.value))}
                />
              </div>
            </div>
          </>
        );

      case "api":
        return (
          <div className="space-y-4">
            <div>
              <Label className="text-white">API Endpoint</Label>
              <Input
                className="mt-2 bg-[hsl(240,7%,17.6%)] border-[hsl(240,3.7%,20%)] text-white"
                placeholder="https://api.example.com/data"
                value={localConfig.endpoint || ""}
                onChange={(e) => updateConfig("endpoint", e.target.value)}
              />
            </div>
            <div>
              <Label className="text-white">Method</Label>
              <Select value={localConfig.method || "GET"} onValueChange={(value) => updateConfig("method", value)}>
                <SelectTrigger className="mt-2 bg-[hsl(240,7%,17.6%)] border-[hsl(240,3.7%,20%)] text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[hsl(240,7%,17.6%)] border-[hsl(240,3.7%,20%)]">
                  <SelectItem value="GET">GET</SelectItem>
                  <SelectItem value="POST">POST</SelectItem>
                  <SelectItem value="PUT">PUT</SelectItem>
                  <SelectItem value="DELETE">DELETE</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-white">Headers (JSON)</Label>
              <Textarea
                className="mt-2 bg-[hsl(240,7%,17.6%)] border-[hsl(240,3.7%,20%)] text-white font-mono text-sm h-24 resize-none"
                placeholder='{"Authorization": "Bearer token"}'
                value={localConfig.headers || ""}
                onChange={(e) => updateConfig("headers", e.target.value)}
              />
            </div>
          </div>
        );

      case "file":
        return (
          <div className="space-y-4">
            <div>
              <Label className="text-white">File Path</Label>
              <Input
                className="mt-2 bg-[hsl(240,7%,17.6%)] border-[hsl(240,3.7%,20%)] text-white"
                placeholder="/path/to/file.csv"
                value={localConfig.filePath || ""}
                onChange={(e) => updateConfig("filePath", e.target.value)}
              />
            </div>
            <div>
              <Label className="text-white">File Type</Label>
              <Select value={localConfig.fileType || "csv"} onValueChange={(value) => updateConfig("fileType", value)}>
                <SelectTrigger className="mt-2 bg-[hsl(240,7%,17.6%)] border-[hsl(240,3.7%,20%)] text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[hsl(240,7%,17.6%)] border-[hsl(240,3.7%,20%)]">
                  <SelectItem value="csv">CSV</SelectItem>
                  <SelectItem value="json">JSON</SelectItem>
                  <SelectItem value="excel">Excel</SelectItem>
                  <SelectItem value="parquet">Parquet</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center justify-between">
              <Label className="text-white">Has Header Row</Label>
              <Switch
                checked={localConfig.hasHeader ?? true}
                onCheckedChange={(checked) => updateConfig("hasHeader", checked)}
              />
            </div>
          </div>
        );

      case "filter":
        return (
          <div className="space-y-4">
            <div>
              <Label className="text-white">Filter Condition</Label>
              <Textarea
                className="mt-2 bg-[hsl(240,7%,17.6%)] border-[hsl(240,3.7%,20%)] text-white font-mono text-sm h-24 resize-none"
                placeholder="column_name > 100"
                value={localConfig.condition || ""}
                onChange={(e) => updateConfig("condition", e.target.value)}
              />
            </div>
            <div>
              <Label className="text-white">Filter Type</Label>
              <Select value={localConfig.filterType || "simple"} onValueChange={(value) => updateConfig("filterType", value)}>
                <SelectTrigger className="mt-2 bg-[hsl(240,7%,17.6%)] border-[hsl(240,3.7%,20%)] text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[hsl(240,7%,17.6%)] border-[hsl(240,3.7%,20%)]">
                  <SelectItem value="simple">Simple Condition</SelectItem>
                  <SelectItem value="complex">Complex Query</SelectItem>
                  <SelectItem value="regex">Regular Expression</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        );

      case "transform":
        return (
          <div className="space-y-4">
            <div>
              <Label className="text-white">Transformation Script</Label>
              <Textarea
                className="mt-2 bg-[hsl(240,7%,17.6%)] border-[hsl(240,3.7%,20%)] text-white font-mono text-sm h-32 resize-none"
                placeholder="# Python transformation code"
                value={localConfig.script || ""}
                onChange={(e) => updateConfig("script", e.target.value)}
              />
            </div>
            <div>
              <Label className="text-white">Output Columns</Label>
              <Input
                className="mt-2 bg-[hsl(240,7%,17.6%)] border-[hsl(240,3.7%,20%)] text-white"
                placeholder="col1,col2,col3"
                value={localConfig.outputColumns || ""}
                onChange={(e) => updateConfig("outputColumns", e.target.value)}
              />
            </div>
          </div>
        );

      case "export":
        return (
          <div className="space-y-4">
            <div>
              <Label className="text-white">Output Path</Label>
              <Input
                className="mt-2 bg-[hsl(240,7%,17.6%)] border-[hsl(240,3.7%,20%)] text-white"
                placeholder="/output/data.csv"
                value={localConfig.outputPath || ""}
                onChange={(e) => updateConfig("outputPath", e.target.value)}
              />
            </div>
            <div>
              <Label className="text-white">Format</Label>
              <Select value={localConfig.format || "csv"} onValueChange={(value) => updateConfig("format", value)}>
                <SelectTrigger className="mt-2 bg-[hsl(240,7%,17.6%)] border-[hsl(240,3.7%,20%)] text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[hsl(240,7%,17.6%)] border-[hsl(240,3.7%,20%)]">
                  <SelectItem value="csv">CSV</SelectItem>
                  <SelectItem value="json">JSON</SelectItem>
                  <SelectItem value="parquet">Parquet</SelectItem>
                  <SelectItem value="database">Database</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        );

      default:
        return (
          <div className="text-center py-4">
            <p className="text-gray-400">No specific configuration available for this node type.</p>
          </div>
        );
    }
  };

  return (
    <div 
      className={`properties-surface border-l border-[hsl(240,3.7%,20%)] transition-all duration-300 ease-in-out flex-shrink-0 ${
        isCollapsed ? 'w-16' : 'w-80'
      }`}
    >
      <div className="p-4 border-b border-[hsl(240,3.7%,20%)]">
        <div className="flex items-center justify-between">
          {!isCollapsed && <h2 className="text-lg font-semibold text-white">Properties</h2>}
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggle}
            className="p-2 hover:bg-[hsl(240,7%,17.6%)] text-gray-400 hover:text-white"
          >
            {isCollapsed ? <ChevronLeft size={16} /> : <ChevronRight size={16} />}
          </Button>
        </div>
      </div>
      
      {!isCollapsed && (
        <div className="p-4 overflow-y-auto h-full custom-scrollbar">
          {!selectedNode ? (
            <div className="text-center py-12">
              <MousePointer className="mx-auto h-12 w-12 text-gray-400 mb-4" />
              <p className="text-gray-400">Select a node to view properties</p>
            </div>
          ) : (
            <div className="space-y-6">
              {/* General Properties */}
              <div>
                <h3 className="text-sm font-medium text-gray-400 mb-3 uppercase tracking-wide">
                  General
                </h3>
                <div className="space-y-4">
                  <div>
                    <Label className="text-white">Process ID</Label>
                    <div className="mt-2 p-3 bg-[hsl(240,7%,10%)] border border-[hsl(240,3.7%,20%)] rounded-md">
                      <span className="text-blue-400 font-mono text-sm">
                        {(() => {
                          // Calculate execution order based on workflow dependencies
                          const executionOrder: string[] = [];
                          const inDegree = new Map<string, number>();
                          const graph = new Map<string, string[]>();
                          
                          // Get edges from parent component (assuming they're available through a context or prop)
                          // For now, we'll use a simpler approach based on node index
                          const nodeIndex = nodes.findIndex(n => n.id === selectedNode.id);
                          return String(nodeIndex + 1);
                        })()}
                      </span>
                    </div>
                  </div>
                  <div>
                    <Label className="text-white">Name</Label>
                    <Input
                      className="mt-2 bg-[hsl(240,7%,17.6%)] border-[hsl(240,3.7%,20%)] text-white"
                      value={selectedNode.data.label}
                      onChange={(e) => updateConfig("label", e.target.value)}
                    />
                  </div>
                  <div>
                    <Label className="text-white">Description</Label>
                    <Textarea
                      className="mt-2 bg-[hsl(240,7%,17.6%)] border-[hsl(240,3.7%,20%)] text-white h-20 resize-none"
                      placeholder="Node description..."
                      value={localConfig.description || ""}
                      onChange={(e) => updateConfig("description", e.target.value)}
                    />
                  </div>
                </div>
              </div>

              {/* Node-specific Configuration */}
              <div>
                <h3 className="text-sm font-medium text-gray-400 mb-3 uppercase tracking-wide">
                  Configuration
                </h3>
                {renderNodeSpecificConfig()}
              </div>

              {/* Advanced Properties */}
              <div>
                <h3 className="text-sm font-medium text-gray-400 mb-3 uppercase tracking-wide">
                  Advanced
                </h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label className="text-white">Enable Caching</Label>
                    <Switch
                      checked={localConfig.cacheEnabled ?? false}
                      onCheckedChange={(checked) => updateConfig("cacheEnabled", checked)}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label className="text-white">Retry on Failure</Label>
                    <Switch
                      checked={localConfig.retryEnabled ?? true}
                      onCheckedChange={(checked) => updateConfig("retryEnabled", checked)}
                    />
                  </div>
                  {localConfig.retryEnabled && (
                    <div>
                      <Label className="text-white">Max Retries</Label>
                      <Input
                        type="number"
                        className="mt-2 bg-[hsl(240,7%,17.6%)] border-[hsl(240,3.7%,20%)] text-white"
                        value={localConfig.maxRetries || 3}
                        onChange={(e) => updateConfig("maxRetries", parseInt(e.target.value))}
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
