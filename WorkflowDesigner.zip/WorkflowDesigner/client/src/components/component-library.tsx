import { ChevronLeft, ChevronRight, Database, Cloud, FileText, Filter, Wand2, BarChart3, Link, Download, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ComponentLibraryProps {
  isCollapsed: boolean;
  onToggle: () => void;
  onAddNode: (nodeType: string, position: { x: number; y: number }) => void;
}

interface ComponentItem {
  type: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  bgColor: string;
}

const DATA_SOURCES: ComponentItem[] = [
  {
    type: "database",
    name: "Database",
    description: "SQL/NoSQL source",
    icon: <Database size={16} />,
    bgColor: "bg-blue-600",
  },
  {
    type: "api",
    name: "API",
    description: "REST/GraphQL API",
    icon: <Cloud size={16} />,
    bgColor: "bg-green-600",
  },
  {
    type: "file",
    name: "File Input",
    description: "CSV, JSON, Excel",
    icon: <FileText size={16} />,
    bgColor: "bg-purple-600",
  },
];

const PROCESSING: ComponentItem[] = [
  {
    type: "filter",
    name: "Filter",
    description: "Data filtering",
    icon: <Filter size={16} />,
    bgColor: "bg-orange-600",
  },
  {
    type: "transform",
    name: "Transform",
    description: "Data transformation",
    icon: <Wand2 size={16} />,
    bgColor: "bg-teal-600",
  },
  {
    type: "aggregate",
    name: "Aggregate",
    description: "Group & summarize",
    icon: <BarChart3 size={16} />,
    bgColor: "bg-red-600",
  },
  {
    type: "join",
    name: "Join",
    description: "Merge datasets",
    icon: <Link size={16} />,
    bgColor: "bg-indigo-600",
  },
];

const OUTPUTS: ComponentItem[] = [
  {
    type: "export",
    name: "Export",
    description: "Save to file/DB",
    icon: <Download size={16} />,
    bgColor: "bg-yellow-600",
  },
  {
    type: "email",
    name: "Email",
    description: "Send notification",
    icon: <Mail size={16} />,
    bgColor: "bg-pink-600",
  },
];

export default function ComponentLibrary({ isCollapsed, onToggle }: ComponentLibraryProps) {
  const onDragStart = (event: React.DragEvent, nodeType: string) => {
    event.dataTransfer.setData('application/reactflow', nodeType);
    event.dataTransfer.effectAllowed = 'move';
  };

  const ComponentSection = ({ title, items }: { title: string; items: ComponentItem[] }) => (
    <div className="mb-6">
      {!isCollapsed && (
        <h3 className="text-sm font-medium text-gray-400 mb-3 uppercase tracking-wide">
          {title}
        </h3>
      )}
      <div className="space-y-2">
        {items.map((item) => (
          <div
            key={item.type}
            className="component-item p-3 rounded-lg cursor-move hover:bg-[hsl(240,7%,20%)] transition-colors"
            draggable
            onDragStart={(event) => onDragStart(event, item.type)}
            title={isCollapsed ? `${item.name} - ${item.description}` : undefined}
          >
            <div className="flex items-center space-x-3">
              <div className={`w-8 h-8 ${item.bgColor} rounded flex items-center justify-center flex-shrink-0`}>
                {item.icon}
              </div>
              {!isCollapsed && (
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-white truncate">{item.name}</div>
                  <div className="text-xs text-gray-400 truncate">{item.description}</div>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div 
      className={`sidebar-surface border-r border-[hsl(240,3.7%,20%)] transition-all duration-300 ease-in-out flex-shrink-0 ${
        isCollapsed ? 'w-16' : 'w-72'
      }`}
    >
      <div className="p-4 border-b border-[hsl(240,3.7%,20%)]">
        <div className="flex items-center justify-between">
          {!isCollapsed && <h2 className="text-lg font-semibold text-white">Components</h2>}
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggle}
            className="p-2 hover:bg-[hsl(240,7%,17.6%)] text-gray-400 hover:text-white"
          >
            {isCollapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
          </Button>
        </div>
      </div>
      
      <div className={`${isCollapsed ? 'p-2' : 'p-4'} space-y-6 overflow-y-auto h-full custom-scrollbar`}>
        <ComponentSection title="Data Sources" items={DATA_SOURCES} />
        <ComponentSection title="Processing" items={PROCESSING} />
        <ComponentSection title="Outputs" items={OUTPUTS} />
      </div>
    </div>
  );
}
