import { useState } from "react";
import { Play, Code, Download, Save, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { WorkflowNode, WorkflowConnection } from "@/lib/workflow-types";

interface WorkflowToolbarProps {
  workflowName: string;
  onWorkflowNameChange: (name: string) => void;
  nodes: WorkflowNode[];
  edges: WorkflowConnection[];
  onDeleteSelected: () => void;
  hasSelectedNode: boolean;
}

export default function WorkflowToolbar({
  workflowName,
  onWorkflowNameChange,
  nodes,
  edges,
  onDeleteSelected,
  hasSelectedNode,
}: WorkflowToolbarProps) {
  const { toast } = useToast();
  const [validationResult, setValidationResult] = useState<any>(null);
  const [pythonCode, setPythonCode] = useState<string>("");
  const [showValidationDialog, setShowValidationDialog] = useState(false);
  const [showPythonDialog, setShowPythonDialog] = useState(false);

  const validateMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/workflows/validate", {
        nodes,
        edges,
      });
      return response.json();
    },
    onSuccess: (data) => {
      setValidationResult(data);
      setShowValidationDialog(true);
      if (data.isValid) {
        toast({
          title: "Validation Successful",
          description: "Your workflow is valid and ready to run!",
        });
      } else {
        toast({
          title: "Validation Failed",
          description: `Found ${data.errors.length} issue(s) in your workflow.`,
          variant: "destructive",
        });
      }
    },
    onError: () => {
      toast({
        title: "Validation Error",
        description: "Failed to validate workflow. Please try again.",
        variant: "destructive",
      });
    },
  });

  const pythonMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/workflows/generate-python", {
        nodes,
        edges,
      });
      return response.json();
    },
    onSuccess: (data) => {
      setPythonCode(data.code);
      setShowPythonDialog(true);
    },
    onError: () => {
      toast({
        title: "Code Generation Error",
        description: "Failed to generate Python code. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleValidate = () => {
    if (nodes.length === 0) {
      toast({
        title: "Empty Workflow",
        description: "Add some nodes to your workflow before validating.",
        variant: "destructive",
      });
      return;
    }
    validateMutation.mutate();
  };

  const handleGeneratePython = () => {
    if (nodes.length === 0) {
      toast({
        title: "Empty Workflow",
        description: "Add some nodes to your workflow before generating code.",
        variant: "destructive",
      });
      return;
    }
    pythonMutation.mutate();
  };

  const handleExportJSON = () => {
    if (nodes.length === 0) {
      toast({
        title: "Empty Workflow",
        description: "Add some nodes to your workflow before exporting.",
        variant: "destructive",
      });
      return;
    }

    const workflowData = {
      name: workflowName,
      description: "Workflow created with Visual Workflow Designer",
      nodes,
      edges,
      createdAt: new Date().toISOString(),
    };

    const dataStr = JSON.stringify(workflowData, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `${workflowName.toLowerCase().replace(/\s+/g, '_')}_workflow.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();

    toast({
      title: "Export Successful",
      description: "Workflow JSON has been downloaded.",
    });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to Clipboard",
      description: "Content has been copied to your clipboard.",
    });
  };

  return (
    <>
      <div className="toolbar-surface border-b border-[hsl(240,3.7%,20%)] px-6 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h1 className="text-xl font-semibold text-white">Workflow Designer</h1>
            <Input
              className="bg-[hsl(240,7%,17.6%)] border-[hsl(240,3.7%,20%)] text-white w-64"
              value={workflowName}
              onChange={(e) => onWorkflowNameChange(e.target.value)}
              placeholder="Workflow name..."
            />
          </div>
          
          <div className="flex items-center space-x-3">
            <Button
              variant="outline"
              size="sm"
              onClick={handleValidate}
              disabled={validateMutation.isPending}
              className="bg-[hsl(240,7%,17.6%)] border-[hsl(240,3.7%,20%)] text-white hover:bg-[hsl(240,7%,20%)]"
            >
              <Play size={16} className="mr-2" />
              Validate
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onClick={handleGeneratePython}
              disabled={pythonMutation.isPending}
              className="bg-[hsl(240,7%,17.6%)] border-[hsl(240,3.7%,20%)] text-white hover:bg-[hsl(240,7%,20%)]"
            >
              <Code size={16} className="mr-2" />
              Generate Python
            </Button>
            
            <Button
              size="sm"
              onClick={handleExportJSON}
              className="bg-[hsl(207,90%,54%)] hover:bg-[hsl(207,90%,45%)] text-white"
            >
              <Download size={16} className="mr-2" />
              Export JSON
            </Button>

            {hasSelectedNode && (
              <Button
                variant="outline"
                size="sm"
                onClick={onDeleteSelected}
                className="bg-red-600 hover:bg-red-700 border-red-600 text-white"
              >
                <Trash2 size={16} className="mr-2" />
                Delete Node
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Validation Dialog */}
      <Dialog open={showValidationDialog} onOpenChange={setShowValidationDialog}>
        <DialogContent className="bg-[hsl(240,7%,17.6%)] border-[hsl(240,3.7%,20%)] text-white max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-white">
              Workflow Validation {validationResult?.isValid ? "✅" : "❌"}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            {validationResult?.isValid ? (
              <div className="p-4 bg-green-900/30 border border-green-700 rounded-lg">
                <p className="text-green-400">✅ Your workflow is valid and ready to execute!</p>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="p-4 bg-red-900/30 border border-red-700 rounded-lg">
                  <p className="text-red-400 font-medium">❌ Validation failed with the following issues:</p>
                </div>
                <ScrollArea className="h-48">
                  <div className="space-y-2">
                    {validationResult?.errors?.map((error: string, index: number) => (
                      <div key={index} className="p-3 bg-[hsl(240,7%,20%)] border border-[hsl(240,3.7%,25%)] rounded">
                        <p className="text-sm text-red-300">{error}</p>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Python Code Dialog */}
      <Dialog open={showPythonDialog} onOpenChange={setShowPythonDialog}>
        <DialogContent className="bg-[hsl(240,7%,17.6%)] border-[hsl(240,3.7%,20%)] text-white max-w-4xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center justify-between">
              Generated Python Code (Apache Airflow)
              <Button
                variant="outline"
                size="sm"
                onClick={() => copyToClipboard(pythonCode)}
                className="bg-[hsl(240,7%,20%)] border-[hsl(240,3.7%,25%)] text-white hover:bg-[hsl(240,7%,25%)]"
              >
                Copy Code
              </Button>
            </DialogTitle>
          </DialogHeader>
          
          <ScrollArea className="h-96">
            <pre className="bg-[hsl(240,7%,10%)] p-4 rounded-lg text-sm font-mono text-white overflow-x-auto">
              <code>{pythonCode}</code>
            </pre>
          </ScrollArea>
          
          <div className="flex justify-end space-x-2">
            <Button
              variant="outline"
              onClick={() => {
                const dataStr = pythonCode;
                const dataUri = 'data:text/plain;charset=utf-8,'+ encodeURIComponent(dataStr);
                const exportFileDefaultName = `${workflowName.toLowerCase().replace(/\s+/g, '_')}_workflow.py`;
                
                const linkElement = document.createElement('a');
                linkElement.setAttribute('href', dataUri);
                linkElement.setAttribute('download', exportFileDefaultName);
                linkElement.click();

                toast({
                  title: "Python Code Downloaded",
                  description: "The Python file has been saved to your downloads.",
                });
              }}
              className="bg-[hsl(240,7%,20%)] border-[hsl(240,3.7%,25%)] text-white hover:bg-[hsl(240,7%,25%)]"
            >
              <Download size={16} className="mr-2" />
              Download .py
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
