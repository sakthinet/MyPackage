import { useCallback, useMemo, useState } from "react";
import ReactFlow, {
  Background,
  Controls,
  MiniMap,
  Node,
  Edge,
  addEdge,
  useNodesState,
  useEdgesState,
  Connection,
  NodeTypes,
  MarkerType,
  ConnectionLineType,
  Handle,
  Position,
} from "reactflow";
import "reactflow/dist/style.css";
import { WorkflowNode, WorkflowConnection } from "@/lib/workflow-types";
import { Database, Cloud, FileText, Filter, Wand2, BarChart3, Link, Download, Mail, MoreVertical, Trash2, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

interface WorkflowCanvasProps {
  nodes: WorkflowNode[];
  edges: WorkflowConnection[];
  selectedNode: WorkflowNode | null;
  onNodesChange: (changes: any) => void;
  onEdgesChange: (changes: any) => void;
  onConnect: (connection: Connection) => void;
  onNodeSelect: (node: WorkflowNode | null) => void;
  onAddNode: (nodeType: string, position: { x: number; y: number }) => void;
  onDeleteNode: (nodeId: string) => void;
}

// Custom node component
function CustomNode({ data, selected }: { data: any; selected: boolean }) {
  const [showMenu, setShowMenu] = useState(false);

  const getNodeIcon = (type: string) => {
    const iconProps = { size: 16, className: "text-white" };
    switch (type) {
      case "database": return <Database {...iconProps} />;
      case "api": return <Cloud {...iconProps} />;
      case "file": return <FileText {...iconProps} />;
      case "filter": return <Filter {...iconProps} />;
      case "transform": return <Wand2 {...iconProps} />;
      case "aggregate": return <BarChart3 {...iconProps} />;
      case "join": return <Link {...iconProps} />;
      case "export": return <Download {...iconProps} />;
      case "email": return <Mail {...iconProps} />;
      default: return <Database {...iconProps} />;
    }
  };

  const getNodeColor = (type: string) => {
    switch (type) {
      case "database": return "bg-blue-600";
      case "api": return "bg-green-600";
      case "file": return "bg-purple-600";
      case "filter": return "bg-orange-600";
      case "transform": return "bg-teal-600";
      case "aggregate": return "bg-red-600";
      case "join": return "bg-indigo-600";
      case "export": return "bg-yellow-600";
      case "email": return "bg-pink-600";
      default: return "bg-gray-600";
    }
  };

  const handleDeleteNode = () => {
    if (data.onDeleteNode) {
      data.onDeleteNode(data.nodeId);
    }
    setShowMenu(false);
  };

  const handleShowProperties = () => {
    if (data.onNodeSelect && data.fullNode) {
      data.onNodeSelect(data.fullNode);
    }
    setShowMenu(false);
  };

  const isInputNode = ['database', 'api', 'file'].includes(data.nodeType);
  const isOutputNode = ['export', 'email'].includes(data.nodeType);

  return (
    <div className={`workflow-node rounded-lg p-4 shadow-lg min-w-[200px] relative ${selected ? 'selected' : ''}`}>
      {/* Input Handle - only show for non-input nodes */}
      {!isInputNode && (
        <Handle
          type="target"
          position={Position.Left}
          className="w-3 h-3 !bg-blue-500 !border-2 !border-white"
          style={{ left: -6 }}
        />
      )}
      
      {/* Output Handle - only show for non-output nodes */}
      {!isOutputNode && (
        <Handle
          type="source"
          position={Position.Right}
          className="w-3 h-3 !bg-blue-500 !border-2 !border-white"
          style={{ right: -6 }}
        />
      )}

      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center space-x-3 flex-1">
          <div className={`w-8 h-8 ${getNodeColor(data.nodeType)} rounded flex items-center justify-center`}>
            {getNodeIcon(data.nodeType)}
          </div>
          <div className="flex-1">
            <div className="font-medium text-white">{data.label}</div>
            <div className="text-xs text-gray-400">{data.subtitle || data.nodeType}</div>
          </div>
        </div>
        
        <DropdownMenu open={showMenu} onOpenChange={setShowMenu}>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0 text-gray-400 hover:text-white hover:bg-[hsl(240,7%,25%)]"
            >
              <MoreVertical size={14} />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent 
            className="bg-[hsl(240,7%,17.6%)] border-[hsl(240,3.7%,20%)] text-white"
            align="end"
          >
            <DropdownMenuItem 
              onClick={handleShowProperties}
              className="cursor-pointer hover:bg-[hsl(240,7%,25%)] focus:bg-[hsl(240,7%,25%)]"
            >
              <Settings size={14} className="mr-2" />
              Properties
            </DropdownMenuItem>
            <DropdownMenuItem 
              onClick={handleDeleteNode}
              className="cursor-pointer text-red-400 hover:bg-red-900/30 focus:bg-red-900/30"
            >
              <Trash2 size={14} className="mr-2" />
              Remove
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
      
      {/* Process ID */}
      <div className="mt-2 pt-2 border-t border-[hsl(240,3.7%,25%)]">
        <div className="text-xs text-gray-500">
          Process ID: <span className="text-blue-400 font-mono">{data.processId}</span>
        </div>
      </div>
    </div>
  );
}

const nodeTypes: NodeTypes = {
  custom: CustomNode,
};

export default function WorkflowCanvas({
  nodes,
  edges,
  selectedNode,
  onNodesChange,
  onEdgesChange,
  onConnect,
  onNodeSelect,
  onAddNode,
  onDeleteNode,
}: WorkflowCanvasProps) {
  // Calculate execution order based on workflow dependencies
  const getExecutionOrder = useCallback(() => {
    const executionOrder: string[] = [];
    const visited = new Set<string>();
    const inDegree = new Map<string, number>();
    const graph = new Map<string, string[]>();
    
    // Initialize graph and in-degree
    nodes.forEach(node => {
      inDegree.set(node.id, 0);
      graph.set(node.id, []);
    });
    
    // Build graph and calculate in-degrees
    edges.forEach(edge => {
      const neighbors = graph.get(edge.source) || [];
      neighbors.push(edge.target);
      graph.set(edge.source, neighbors);
      inDegree.set(edge.target, (inDegree.get(edge.target) || 0) + 1);
    });
    
    // Topological sort to determine execution order
    const queue: string[] = [];
    inDegree.forEach((degree, nodeId) => {
      if (degree === 0) queue.push(nodeId);
    });
    
    while (queue.length > 0) {
      const current = queue.shift()!;
      executionOrder.push(current);
      
      const neighbors = graph.get(current) || [];
      neighbors.forEach(neighbor => {
        const newDegree = (inDegree.get(neighbor) || 0) - 1;
        inDegree.set(neighbor, newDegree);
        if (newDegree === 0) {
          queue.push(neighbor);
        }
      });
    }
    
    // For isolated nodes, add them at the end
    nodes.forEach(node => {
      if (!executionOrder.includes(node.id)) {
        executionOrder.push(node.id);
      }
    });
    
    return executionOrder;
  }, [nodes, edges]);

  // Convert our workflow nodes to React Flow format
  const reactFlowNodes: Node[] = useMemo(() => {
    const executionOrder = getExecutionOrder();
    
    return nodes.map((node) => {
      const executionIndex = executionOrder.indexOf(node.id);
      const processId = executionIndex >= 0 ? executionIndex + 1 : nodes.length;
      
      return {
        id: node.id,
        type: 'custom',
        position: node.position,
        data: {
          ...node.data,
          nodeType: node.type,
          subtitle: getNodeSubtitle(node.type),
          processId: String(processId),
          nodeId: node.id,
          fullNode: node,
          onDeleteNode,
          onNodeSelect,
        },
        selected: selectedNode?.id === node.id,
      };
    });
  }, [nodes, selectedNode, onDeleteNode, onNodeSelect, getExecutionOrder]);

  // Convert our workflow edges to React Flow format
  const reactFlowEdges: Edge[] = useMemo(() => {
    return edges.map((edge) => ({
      id: edge.id,
      source: edge.source,
      target: edge.target,
      sourceHandle: edge.sourceHandle,
      targetHandle: edge.targetHandle,
      animated: true,
      type: 'smoothstep',
      markerEnd: {
        type: MarkerType.ArrowClosed,
        width: 20,
        height: 20,
        color: 'hsl(207, 90%, 54%)',
      },
      style: {
        stroke: 'hsl(207, 90%, 54%)',
        strokeWidth: 2,
      },
    }));
  }, [edges]);

  const onNodeClick = useCallback((event: React.MouseEvent, node: Node) => {
    const workflowNode = nodes.find((n) => n.id === node.id);
    onNodeSelect(workflowNode || null);
  }, [nodes, onNodeSelect]);

  const onPaneClick = useCallback(() => {
    onNodeSelect(null);
  }, [onNodeSelect]);

  const onDragOver = useCallback((event: React.DragEvent) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  }, []);

  const onDrop = useCallback((event: React.DragEvent) => {
    event.preventDefault();

    const reactFlowBounds = (event.target as Element).getBoundingClientRect();
    const type = event.dataTransfer.getData('application/reactflow');

    if (typeof type === 'undefined' || !type) {
      return;
    }

    const position = {
      x: event.clientX - reactFlowBounds.left - 100,
      y: event.clientY - reactFlowBounds.top - 30,
    };

    onAddNode(type, position);
  }, [onAddNode]);

  return (
    <div className="w-full h-full">
      <ReactFlow
        nodes={reactFlowNodes}
        edges={reactFlowEdges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onNodeClick={onNodeClick}
        onPaneClick={onPaneClick}
        onDrop={onDrop}
        onDragOver={onDragOver}
        nodeTypes={nodeTypes}
        className="workflow-canvas"
        fitView
        attributionPosition="bottom-left"
        connectionLineStyle={{
          stroke: 'hsl(207, 90%, 54%)',
          strokeWidth: 2,
        }}
        connectionLineType={ConnectionLineType.SmoothStep}
      >
        <Controls className="text-white" />
        <MiniMap 
          nodeColor="#374151"
          maskColor="rgba(0, 0, 0, 0.2)"
          className="!bg-[hsl(240,7%,17.6%)] !border-[hsl(240,3.7%,20%)]"
        />
        <Background 
          color="#333" 
          gap={20} 
          size={1}
          className="workflow-canvas"
        />
      </ReactFlow>
    </div>
  );
}

function getNodeSubtitle(nodeType: string): string {
  const subtitles: { [key: string]: string } = {
    database: "SQL/NoSQL source",
    api: "REST/GraphQL API",
    file: "CSV, JSON, Excel",
    filter: "Data filtering",
    transform: "Data transformation",
    aggregate: "Group & summarize",
    join: "Merge datasets",
    export: "Save to file/DB",
    email: "Send notification",
  };
  return subtitles[nodeType] || "";
}
